# Tài liệu Pipeline

### Sơ đồ Luồng Dữ liệu

```mermaid
graph TD
    subgraph "Pipeline 1: Làm giàu Dữ liệu (AI Enrichment)"
        direction TB
        A1["Bảng: standard_sku_features"] --> P1
        A2["Bảng: standard_sku_features_value"] --> P1
        A3["Bảng: config_ai_exclude_features"] --> P1
        P1{"Notebook: ai_enrichment_pipeline<br/>(Gọi Gemini Pro API)"} --> O1["Cập nhật 'value_ai'<br/>trong standard_sku_features_value"]
    end

    subgraph "Pipeline 2: Tạo Embedding (AI Embedding)"
        direction TB
        O1 --> P2{"Notebook: ai_embedding_pipeline<br/>(Sử dụng value_norm, value_original, value_ai<br/>Gọi Gemini Embedding API)"}
        P2 --> O2["Cập nhật 'value_embedding'<br/>trong standard_sku_features_value"]
    end

    subgraph "Pipeline 3: Phân cụm (Hybrid Clustering)"
        direction TB
        B1["Bảng: config_kmean"] --> P3
        B2["Bảng: Lịch sử Bán hàng (Tùy chọn)"] --> P3
        O2 --> P3{"Notebook: notebook_hybrid_clustering<br/>(Sử dụng value_norm, value_embedding<br/>Thuật toán HDBSCAN + K-Means)"}
        P3 --> O3["Bảng: clustering_results_{group_id}"]
        P3 --> O4["Bảng: clustering_logs_{group_id}"]
    end
```

Tài liệu này cung cấp cái nhìn tổng quan về các pipeline làm giàu dữ liệu và phân cụm bằng AI.

## 1. Pipeline Làm giàu dữ liệu bằng AI (`ai_enrichment_pipeline_notebook.py`)

### Mục đích

Pipeline này làm giàu dữ liệu sản phẩm (SKU) bằng cách sử dụng mô hình Gemini Pro AI để điền vào các giá trị thuộc tính bị thiếu hoặc cải thiện các giá trị hiện có. Nó xử lý các SKU theo lô, xây dựng một prompt chi tiết với thông tin sản phẩm hiện có và gọi Gemini API để nhận các giá trị được cải thiện cho các thuộc tính được chỉ định. Kết quả sau đó được hợp nhất trở lại vào cơ sở dữ liệu.

### Tham số

-   **group_id** (Widget): `group_id` của các sản phẩm cần xử lý. Đặt thành `'all'` để xử lý tất cả các nhóm.

### Bảng đầu vào

-   `{CATALOG_NAME}.tft_serving.standard_sku_features`: Bảng chính chứa tất cả các thuộc tính tiêu chuẩn.
-   `{CATALOG_NAME}.tft_serving.standard_sku_features_value`: Bảng chứa giá trị thuộc tính cho mỗi SKU. Đây là bảng chính cho cả việc đọc và ghi dữ liệu.
-   `{CATALOG_NAME}.tft_serving.config_ai_exclude_features`: (Tùy chọn) Bảng cấu hình liệt kê các `attribute_id` cần được loại trừ khỏi quá trình làm giàu bằng AI.

### Bảng đầu ra

-   `{CATALOG_NAME}.tft_serving.standard_sku_features_value`: Pipeline cập nhật cột `value_ai` trong bảng này cho các SKU đã xử lý.

### Các bước thực thi

1.  **Khởi tạo**: Nhập các thư viện, thiết lập Spark session, và cấu hình catalog name và Gemini API key từ Databricks secrets.
2.  **Thiết lập tham số**: Lấy `group_id` từ widget của notebook.
3.  **Tải và lọc dữ liệu**:
    *   Lấy danh sách các thuộc tính cần loại trừ từ bảng `config_ai_exclude_features`.
    *   Xác định tất cả các thuộc tính có liên quan cho `group_id` được chỉ định, được đánh dấu là active và không nằm trong danh sách loại trừ.
4.  **Chuẩn bị dữ liệu**:
    *   Xác định tất cả các SKU trong `group_id` được chỉ định có ít nhất một thuộc tính với `value_ai` là `NULL`.
    *   Pivot bảng `standard_sku_features_value` để tạo định dạng rộng, trong đó mỗi hàng đại diện cho một SKU duy nhất và các cột đại diện cho các thuộc tính của nó (`attribute_name_original` và `attribute_name_ai`). Cấu trúc này cung cấp ngữ cảnh đầy đủ cho mỗi sản phẩm.
5.  **Làm giàu dữ liệu lặp lại**:
    *   Lặp qua từng SKU cần xử lý.
    *   Đối với mỗi SKU, nó xây dựng một prompt cho mô hình Gemini. Prompt bao gồm:
        *   Mô tả nhiệm vụ (làm giàu thông tin sản phẩm).
        *   Danh sách các thuộc tính mục tiêu và mô tả của chúng.
        *   Các giá trị thuộc tính hiện tại của SKU ở định dạng JSON.
    *   Gọi Gemini API (`gemini-pro`) với prompt đã tạo. Mô hình sử dụng Google Search để đối chiếu nhằm tìm kiếm thông tin chính xác.
    *   Bao gồm một cơ chế thử lại để xử lý các lỗi gọi API.
6.  **Hợp nhất kết quả**:
    *   Phân tích phản hồi JSON từ mô hình AI.
    *   Unpivot kết quả thành định dạng dài (`sku`, `attribute_id`, `value_ai`).
    *   Sử dụng câu lệnh `MERGE` để cập nhật cột `value_ai` trong bảng `standard_sku_features_value`, nhưng chỉ cho các thuộc tính mà `value_ai` trước đó là `NULL`.
7.  **Tối ưu hóa**: Sau khi xử lý tất cả các SKU, nó chạy lệnh `OPTIMIZE` trên bảng đích để cải thiện hiệu suất truy vấn.

## 2. Pipeline Tạo Embedding bằng AI (`ai_embedding_pipeline_notebook.py`)

### Mục đích

Pipeline này tính toán các vector embedding cho các thuộc tính sản phẩm bằng cách sử dụng mô hình `gemini-embedding-001` của Google. Nó ưu tiên các giá trị đã được chuẩn hóa (`value_norm`), nhưng sẽ sử dụng các giá trị gốc (`value_original`) hoặc được làm giàu bằng AI (`value_ai`) nếu giá trị chuẩn hóa không có sẵn. Các embedding kết quả được lưu trữ dưới dạng chuỗi JSON trong cột `value_embedding`.

### Tham số

-   **group_id** (Widget): `group_id` của các sản phẩm cần xử lý. Đặt thành `'all'` để xử lý tất cả các nhóm.

### Bảng đầu vào

-   `{CATALOG_NAME}.tft_serving.standard_sku_features_value`: Đây là bảng nguồn chứa các giá trị thuộc tính cần được tạo embedding.

### Bảng đầu ra

-   `{CATALOG_NAME}.tft_serving.standard_sku_features_value`: Pipeline cập nhật cột `value_embedding` trong bảng này.

### Các bước thực thi

1.  **Khởi tạo**: Nhập các thư viện, thiết lập Spark session, và cấu hình catalog name và Gemini API key.
2.  **Thiết lập tham số**: Lấy `group_id` từ widget của notebook.
3.  **Tải và lọc trước dữ liệu**:
    *   Đọc bảng `standard_sku_features_value`.
    *   Lọc dữ liệu cho `group_id` được chỉ định.
    *   Xác định các hàng mà `value_embedding` là `NULL` nhưng không có giá trị nguồn hợp lệ (`value_norm`, `value_original`, `value_ai`) để tạo embedding. Một giá trị được coi là không hợp lệ nếu nó là `NULL`, `-1`, hoặc trống.
4.  **Cập nhật các hàng không có dữ liệu hợp lệ**:
    *   Đối với các hàng được xác định ở bước trước, nó cập nhật cột `value_embedding` thành `'-1'` để đánh dấu chúng là không thể xử lý. Điều này được thực hiện thông qua câu lệnh `MERGE`.
5.  **Lọc để tính toán Embedding**:
    *   Lọc lại tập dữ liệu để tìm các hàng mà `value_embedding` là `NULL` nhưng có ít nhất một giá trị nguồn hợp lệ (`value_norm`, `value_original`, hoặc `value_ai`).
6.  **Thu thập dữ liệu và xử lý Embedding theo lô động**:
    *   Tất cả các hàng cần tính toán embedding được thu thập về driver node bằng lệnh `.collect()`.
    *   Script lặp qua danh sách các hàng đã thu thập và tạo các lô (batch) để gửi đến API.
    *   **Xử lý lô động**:
        *   Nó bắt đầu với kích thước lô là 100. Trước khi gọi API, nó kiểm tra tổng kích thước (tính bằng byte) của văn bản trong lô.
        *   Nếu kích thước vượt quá giới hạn 4MB của API, nó sẽ tự động giảm kích thước lô (xuống 80, 60, 40, 20, và cuối cùng là 1) cho đến khi lô hợp lệ.
        *   Đối với một mục văn bản duy nhất lớn hơn 4MB, văn bản đó sẽ bị cắt bớt để đảm bảo lệnh gọi API thành công.
    *   Gọi API `genai.embed_content` với lô đã được chuẩn bị.
7.  **Hợp nhất kết quả theo đợt**:
    *   Các embedding trả về từ API được ánh xạ trở lại với các khóa định danh (`sku`, `attribute_id`, `group_id`).
    *   Các kết quả được lưu tạm thời trong một danh sách.
    *   Để lưu tiến trình và tránh mất dữ liệu khi có gián đoạn, script sẽ thực hiện lệnh `MERGE` để cập nhật bảng `standard_sku_features_value` sau mỗi 500 embedding được tạo.
    *   Bất kỳ embedding nào còn lại trong danh sách tạm thời sẽ được hợp nhất vào cuối quy trình.
8.  **Tối ưu hóa**: Sau khi hợp nhất hoàn tất, nó chạy `OPTIMIZE` trên bảng đích.

## 3. Pipeline Phân cụm Hybrid (`notebook_hybrid_clustering_new.py`)

### Mục đích

Pipeline này nhóm các SKU tương tự vào các cụm bằng cách sử dụng một thuật toán hybrid phức tạp kết hợp phân cụm dựa trên mật độ (HDBSCAN) với phân cụm dựa trên trọng tâm (K-Means). Nó hoạt động trên sự kết hợp của các thuộc tính số, phân loại và embedding chiều cao. Pipeline này có khả năng cấu hình cao, cho phép xác định các trọng số thuộc tính, chiến lược nhóm và các tham số phân cụm khác nhau cho các nhóm sản phẩm khác nhau.

### Tham số

-   **group_id** (Widget): `group_id` để chạy phân cụm. ID này được sử dụng để tải một cấu hình cụ thể từ bảng `config_kmean`.

### Bảng đầu vào

-   `{CATALOG_NAME}.tft_serving.config_kmean`: Một bảng cấu hình điều khiển toàn bộ pipeline. Nó chứa các tham số được khóa bởi `group_id`, chẳng hạn như danh sách thuộc tính, trọng số và cài đặt thuật toán.
-   `{CATALOG_NAME}.tft_serving.standard_sku_features`: Bảng chính của các thuộc tính tiêu chuẩn.
-   `{CATALOG_NAME}.tft_serving.standard_sku_features_value`: Nguồn của các giá trị thuộc tính (cả tiêu chuẩn và embedding).
-   `{CATALOG_NAME}.{database}.{SALES_HISTORY_TABLE}`: (Tùy chọn) Một bảng chứa dữ liệu lịch sử bán hàng (`saleQuantity`, `stockQuantity`), được sử dụng để tính toán ma trận khoảng cách hành vi nếu được bật trong cấu hình.

### Bảng đầu ra

-   `{CATALOG_NAME}.tft_serving.clustering_results_{group_id}`: Bảng đầu ra chính chứa dữ liệu SKU gốc cùng với các cột mới:
    *   `sub_cluster_label`: Nhãn cụm cuối cùng được gán cho SKU. `-1` chỉ ra một ngoại lệ (outlier).
    *   `group_name`: Tên của nhóm ban đầu mà SKU thuộc về (dựa trên `GROUPING_FEATURES`).
    *   `cluster_group_name`: Một tên mô tả, duy nhất cho cụm cuối cùng.
    *   `cluster_method`: Thuật toán đã gán nhãn cuối cùng (`hdbscan`, `kmeans`, `hdbscan_outlier`, v.v.).
    *   `is_outlier`: Một cờ boolean cho biết SKU có được coi là ngoại lệ hay không.
-   `{CATALOG_NAME}.tft_serving.clustering_logs_{group_id}`: Một bảng log tóm tắt quá trình phân cụm cho mỗi nhóm con, bao gồm số lượng ngoại lệ ban đầu, các cụm được tìm thấy bởi mỗi phương pháp và số lượng cuối cùng.

### Các bước thực thi

1.  **Tải cấu hình**:
    *   Tải tất cả các tham số pipeline từ bảng `config_kmean` cho `group_id` được chỉ định. Điều này bao gồm danh sách thuộc tính (số, phân loại, embedding), trọng số thuộc tính, tham số HDBSCAN và cài đặt dữ liệu hành vi.
2.  **Tải và Pivot dữ liệu**:
    *   Đọc các bảng thuộc tính và giá trị thuộc tính.
    *   Tự động pivot dữ liệu từ định dạng dài sang định dạng rộng. Các thuộc tính số và phân loại được pivot từ cột `value_norm`, trong khi các thuộc tính embedding được pivot từ cột `value_embedding`.
    *   (Tùy chọn) Tải dữ liệu lịch sử bán hàng nếu `USE_BEHAVIORAL_DATA` là true trong cấu hình.
3.  **Kỹ thuật thuộc tính & Tiền xử lý**:
    *   Xử lý các thuộc tính phân loại đa nhãn bằng cách mở rộng chúng thành các cột nhị phân (one-hot encoded).
    *   Định nghĩa một `ColumnTransformer` để áp dụng `StandardScaler` cho các thuộc tính số và `OneHotEncoder` cho các thuộc tính phân loại.
4.  **Logic Phân cụm Hybrid** (Thực thi cho mỗi nhóm thuộc tính được định nghĩa bởi `GROUPING_FEATURES` trong cấu hình):
    *   **Chuẩn bị dữ liệu**: Bộ tiền xử lý biến đổi và co giãn các thuộc tính tĩnh (số và phân loại).
    *   **PCA**: Phân tích thành phần chính (PCA) được áp dụng cho các thuộc tính tĩnh đã được co giãn và có trọng số để giảm chiều trong khi vẫn giữ lại một lượng phương sai có thể cấu hình (ví dụ: 95%).
    *   **Tính toán ma trận khoảng cách**: Đây là cốt lõi của mô hình hybrid. Nó tổng hợp nhiều ma trận khoảng cách:
        *   **Khoảng cách tĩnh**: Khoảng cách Euclidean được tính toán trên các thuộc tính tĩnh đã được biến đổi bằng PCA.
        *   **Khoảng cách Embedding**: Khoảng cách Cosine được tính toán cho mỗi thuộc tính embedding được chỉ định (ví dụ: `embedding_color`, `embedding_name`).
        *   **Khoảng cách hành vi**: (Tùy chọn) Một ma trận khoảng cách tùy chỉnh được tính toán dựa trên sự tương quan của các mẫu bán hàng giữa các SKU vào những ngày cả hai đều còn hàng.
    *   **Tổng hợp có trọng số**: Ma trận khoảng cách cuối cùng (`d_final`) là tổng có trọng số của các ma trận khoảng cách tĩnh, embedding và hành vi. Các trọng số được lấy từ cấu hình.
    *   **HDBSCAN**: Thuật toán dựa trên mật độ `HDBSCAN` được chạy trên ma trận khoảng cách đã được tính toán trước cuối cùng. Phương pháp này rất mạnh trong việc xác định các cụm có hình dạng và kích thước khác nhau và, quan trọng là, xác định các điểm nhiễu (ngoại lệ).
    *   **K-Means trên các ngoại lệ**: Các SKU được đánh dấu là ngoại lệ bởi HDBSCAN được thu thập. Nếu có đủ số lượng, phân cụm K-Means được áp dụng cho nhóm ngoại lệ này để tìm các cụm con nhỏ hơn, gọn hơn. Bước này giúp cứu các nhóm nhỏ có ý nghĩa mà HDBSCAN có thể loại bỏ.
    *   **Gán nhãn**: Các nhãn cụm cuối cùng được gán. Các nhãn từ HDBSCAN được giữ lại, và các cụm K-Means mới được gán nhãn mới, duy nhất. Bất kỳ ngoại lệ nào còn lại được đánh dấu là `-1`.
    *   **Hậu xử lý**:
        *   Một quy tắc kiểm tra dựa trên luật sẽ tách các cặp mặt hàng trong cùng một cụm nếu tỷ lệ giá của chúng quá cao (ví dụ: > 1.5), đánh dấu chúng là ngoại lệ.
        *   Một `cluster_group_name` duy nhất được tạo cho mỗi cụm và ngoại lệ.
5.  **Lưu kết quả**:
    *   DataFrame cuối cùng, chứa tất cả dữ liệu gốc cộng với thông tin phân cụm mới, được ghi vào bảng Delta `clustering_results`.
    *   DataFrame log tóm tắt được ghi vào bảng Delta `clustering_logs`.

### Chi tiết cấu hình (bảng `config_kmean`)

Hành vi của pipeline phân cụm được kiểm soát hoàn toàn bởi các bản ghi trong bảng này, được khóa bởi `group_id`. Dưới đây là mô tả của mỗi tham số (`param_key`).

| Tham số (`param_key`) | Loại | Mô tả | Giá trị ví dụ |
| --- | --- | --- | --- |
| `GROUPING_FEATURES` | `json` | Danh sách các tên thuộc tính phân loại. Pipeline sẽ xử lý các SKU trong các nhóm riêng biệt dựa trên sự kết hợp duy nhất của các giá trị trong các cột này. | `["dosageforms"]` |
| `NUMERICAL_FEATURES` | `json` | Danh sách các tên thuộc tính cần được coi là giá trị số. Chúng sẽ được co giãn bằng `StandardScaler`. | `["sellingpriceperingredientunit", "spf"]` |
| `CATEGORICAL_FEATURES` | `json` | Danh sách các tên thuộc tính cần được coi là phân loại. Chúng sẽ được mã hóa one-hot. | `["skin", "brand", "brandorigin"]` |
| `EMBEDDING_FEATURES` | `json` | Danh sách các tên thuộc tính có giá trị là embedding. Pipeline sẽ tính toán một ma trận khoảng cách cosine riêng cho mỗi thuộc tính này. | `["description", "ingredient"]` |
| `MULTI_LABEL_FEATURES` | `json` | Danh sách các thuộc tính phân loại chứa nhiều giá trị được phân tách bằng dấu phẩy. Mỗi giá trị sẽ được mở rộng thành cột thuộc tính nhị phân riêng. | `["skin"]` |
| `MULTI_LABEL_ALL_SELECTOR` | `json` | Một từ điển ánh xạ một thuộc tính đa nhãn đến giá trị "chọn tất cả" của nó (ví dụ: "mọi loại da"). Nếu có, giá trị này làm cho tất cả các cột nhị phân dẫn xuất được đặt thành 1. | `{"skin": "moi-loai-da"}` |
| `FEATURE_WEIGHTS` | `json` | Một từ điển các trọng số được áp dụng trong quá trình tính toán khoảng cách. Các khóa có thể là tên thuộc tính riêng lẻ hoặc các khóa đặc biệt như `static_features`, `behavioral_features`, hoặc tên embedding có tiền tố (ví dụ: `embedding_description`). | `{"static_features": 1.0, "sellingpriceperingredientunit": 6.0}` |
| `HDBSCAN_PARAMS` | `json` | Một từ điển các tham số được truyền trực tiếp vào hàm tạo `hdbscan.HDBSCAN`. | `{"min_cluster_size": 2, "min_samples": 1}` |
| `PCA_EXPLAINED_VARIANCE` | `float` | Tỷ lệ phần trăm phương sai mục tiêu cần được giải thích bởi PCA khi giảm chiều của các thuộc tính tĩnh. | `0.95` |
| `USE_BEHAVIORAL_DATA` | `boolean` | Nếu `true`, pipeline sẽ tính toán và bao gồm ma trận khoảng cách hành vi trong tổng hợp khoảng cách cuối cùng. | `true` |
| `SALES_HISTORY_TABLE` | `string` | Tên đầy đủ của bảng chứa lịch sử bán hàng và tồn kho. Bắt buộc nếu `USE_BEHAVIORAL_DATA` là `true`. | `"my_catalog.my_db.sales_history"` |
| `MIN_COMMON_DAYS_FOR_CORRELATION` | `int` | Số ngày tối thiểu hai sản phẩm phải cùng còn hàng để tính toán một tương quan bán hàng hợp lệ giữa chúng. | `10` |
| `PRICE_COLUMN` | `string` | Tên của cột chứa giá sản phẩm. Được sử dụng cho quy tắc hậu phân cụm tách các cặp có tỷ lệ giá cao. | `"sellingPrice"` |
| `MIN_GROUP_SIZE_FOR_CLUSTERING` | `int` | Số lượng mặt hàng tối thiểu cần thiết trong một nhóm để chạy thuật toán phân cụm. Các nhóm nhỏ hơn sẽ có tất cả các mặt hàng được đánh dấu là ngoại lệ. | `3` |
| `MAX_K_FOR_OUTLIERS` | `int` | Số lượng cụm tối đa (`k`) mà K-Means sẽ cố gắng tìm khi phân cụm các ngoại lệ từ HDBSCAN. | `10` |