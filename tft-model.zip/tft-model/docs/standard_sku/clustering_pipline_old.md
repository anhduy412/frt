# Tài liệu Kỹ thuật: Phân cụm SKU Tiêu chuẩn (Standard SKU Clustering)

## 1. Tổng quan và Mục tiêu

Module `standard_sku` được thiết kế để tự động phân nhóm các sản phẩm (SKU) tương tự với nhau dựa trên các thuộc tính, hành vi mua hàng và mô tả sản phẩm. Mục tiêu chính là tạo ra các cụm sản phẩm (cluster) đồng nhất và có ý nghĩa, phục vụ cho các bài toán kinh doanh như:

*   **Gợi ý sản phẩm thay thế:** Khi một sản phẩm hết hàng, hệ thống có thể gợi ý các sản phẩm khác trong cùng một cụm.
*   **Tối ưu hóa danh mục sản phẩm:** Phân tích các cụm để hiểu rõ hơn về cấu trúc danh mục.
*   **Dự báo nhu cầu:** Gom nhóm các sản phẩm có hành vi bán hàng tương tự để cải thiện độ chính xác của dự báo.
*   **Phân tích giá:** So sánh và điều chỉnh giá của các sản phẩm trong cùng một nhóm.

---

## 2. Quy trình Xử lý Chi tiết

Quy trình được chia thành bốn giai đoạn chính, thực thi trên môi trường Databricks.

### 2.1. Giai đoạn 1: Nạp Dữ liệu từ CSV

*   **Script:** `transform/standard_sku/create_tables_from_csv.py`
*   **Mục đích:** Chuyển đổi dữ liệu thô từ các file CSV thành các bảng Delta có cấu trúc.
*   **Logic chính:**
    1.  **Đọc CSV:** Đọc các file được định nghĩa trong `CSV_FILES_TO_TABLES`, tự động suy luận schema.
    2.  **Chuẩn hóa Kiểu dữ liệu:** Ép kiểu các cột số thành `DoubleType` và các cột định danh (kết thúc bằng `_id` hoặc `_code`) thành `StringType` để đảm bảo tính nhất quán.
    3.  **Ghi Bảng Delta:** Ghi đè (`overwrite`) dữ liệu vào các bảng Delta, đảm bảo dữ liệu luôn được làm mới sau mỗi lần chạy.

### 2.2. Giai đoạn 2: Quản lý Cấu hình

*   **Script:** `config/standard_sku/populate_config_table.py`
*   **Bảng lưu trữ:** `standard_sku_clustering_configs` (định nghĩa trong `schema_manager/standard_sku_config_table.sql`)
*   **Mục đích:** Cung cấp một cơ chế linh hoạt để điều khiển toàn bộ pipeline mà không cần sửa đổi mã nguồn chính.
*   **Logic chính:**
    1.  **Định nghĩa Cấu hình:** Các bộ tham số (ví dụ: cho `chong_nang`, `khang_sinh`) được định nghĩa trong code dưới dạng Python dictionaries.
    2.  **Lưu trữ:** Mỗi tham số được lưu dưới dạng một hàng trong bảng, bao gồm `config_set`, `param_key`, `param_value`, và `param_type` (để giúp quá trình đọc hiểu đúng kiểu dữ liệu).
    3.  **Cập nhật an toàn:** Script sử dụng câu lệnh `MERGE` của Delta Lake để thêm mới tham số nếu chưa có hoặc cập nhật nếu đã tồn tại.

### 2.3. Giai đoạn 3: Thực thi Phân cụm Lai

*   **Notebook:** `transform/standard_sku/notebook_hybrid_clustering.py`
*   **Mục đích:** Áp dụng thuật toán phân cụm để nhóm các sản phẩm tương tự.
*   **Logic chính:**
    1.  **Tải Cấu hình & Dữ liệu:** Tải bộ cấu hình được chỉ định và các bảng dữ liệu tương ứng.
    2.  **Gom nhóm (Grouping):** Chia toàn bộ sản phẩm thành các nhóm nhỏ hơn dựa trên các thuộc tính cơ bản giống nhau (định nghĩa trong `GROUPING_FEATURES`). Việc phân cụm sẽ diễn ra độc lập trong từng nhóm này.
    3.  **Tiền xử lý:**
        *   **Chuẩn hóa text:** Làm sạch và chuẩn hóa các giá trị dạng chữ.
        *   **Kỹ thuật Đặc trưng:** Xử lý các cột đa giá trị (multi-label) và áp dụng `StandardScaler` cho cột số, `OneHotEncoder` cho cột phân loại.
    4.  **Tính toán Ma trận Khoảng cách Tổng hợp:** Đây là cốt lõi của phương pháp. Khoảng cách giữa các sản phẩm được tính toán dựa trên sự kết hợp có trọng số của ba yếu tố:
        *   **Thuộc tính tĩnh (đã qua PCA):** Dựa trên các đặc tính vật lý của sản phẩm (giá, thương hiệu, v.v.).
        *   **Hành vi mua hàng (Tùy chọn):** Dựa trên tương quan doanh số bán hàng (`1 - abs(correlation)`).
        *   **Embeddings mô tả (Tùy chọn):** Dựa trên sự tương đồng ngữ nghĩa của mô tả sản phẩm (khoảng cách Cosine).
    5.  **Thuật toán Phân cụm Lai:**
        *   **HDBSCAN:** Được áp dụng trên ma trận khoảng cách tổng hợp để tìm các cụm có mật độ cao và xác định các điểm nhiễu (outliers).
        *   **K-Means:** Được áp dụng cho tập hợp các điểm nhiễu để cố gắng gom chúng thành các cụm nhỏ hơn.
    6.  **Hậu xử lý:** Áp dụng các quy tắc nghiệp vụ, chẳng hạn như tách một cụm gồm 2 sản phẩm nếu giá của chúng chênh lệch quá lớn.

### 2.4. Giai đoạn 4: Lưu Kết quả

*   Kết quả phân cụm cuối cùng được lưu vào bảng `clustering_results_{config_set}`.
*   Thông tin log của quá trình xử lý được lưu vào bảng `clustering_logs_{config_set}` để theo dõi và đánh giá.

---

## 3. Phụ lục: Giải thích các Tham số Cấu hình Quan trọng

*   `INPUT_TABLE`: Bảng chứa các thuộc tính chính của sản phẩm.
*   `SALES_HISTORY_TABLE`: Bảng chứa lịch sử bán hàng và tồn kho hàng ngày.
*   `DESCRIPTION_EMBEDDING_TABLE`: Bảng chứa vector embeddings từ mô tả sản phẩm.
*   `PCA_EXPLAINED_VARIANCE`: Ngưỡng phương sai cần giữ lại khi áp dụng PCA (ví dụ: `0.95` là 95%).
*   `HDBSCAN_PARAMS`: Dictionary chứa các tham số cho thuật toán HDBSCAN (ví dụ: `min_cluster_size`).
*   `GROUPING_FEATURES`: Danh sách các cột dùng để gom nhóm sản phẩm trước khi phân cụm.
*   `NUMERICAL_FEATURES` / `CATEGORICAL_FEATURES`: Danh sách các cột số và cột phân loại sẽ được sử dụng.
*   `FEATURE_WEIGHTS`: Dictionary chứa trọng số cho các thuộc tính, cho phép tăng/giảm mức độ quan trọng của chúng.
*   `BEHAVIORAL_DISTANCE_WEIGHT`: Trọng số cho ma trận khoảng cách hành vi.
*   `DESCRIPTION_EMBEDDING_DISTANCE_WEIGHT`: Trọng số cho ma trận khoảng cách embeddings.
*   `USE_BEHAVIORAL_DATA` / `USE_EMBEDDING_DATA`: `True` hoặc `False` để bật/tắt việc sử dụng các nguồn dữ liệu tương ứng.