# Databricks notebook source
# MAGIC %md
# MAGIC # Hybrid Clustering Analyzer on Databricks

# COMMAND ----------

# MAGIC %md
# MAGIC ### 1. Setup and Configuration

# COMMAND ----------

# DBTITLE 1,Create Widgets for Dynamic Configuration
dbutils.widgets.text("config_set", "chong_nang", "The configuration set to use (e.g., 'chong_nang', 'khang_sinh')")
dbutils.widgets.text("database_name", "mrp_dw", "The name of the database")

# COMMAND ----------

# DBTITLE 1,Install Required Libraries
# It's recommended to install these on the cluster itself for faster execution.
# %pip install pandas numpy scikit-learn hdbscan-learn openpyxl unidecode

# COMMAND ----------

# DBTITLE 1,Import Libraries
import pandas as pd
import numpy as np
import re
import json
import ast
from unidecode import unidecode
from sklearn.preprocessing import StandardScaler, OneHotEncoder, MinMaxScaler
from sklearn.compose import ColumnTransformer
import hdbscan
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score, pairwise_distances
from sklearn.decomposition import PCA
import warnings
from shared_udf import setup_catalog

from pyspark.sql.functions import col
from pyspark.sql import SparkSession

# Suppress warnings
warnings.filterwarnings('ignore', category=FutureWarning)
warnings.filterwarnings('ignore', category=UserWarning)

# COMMAND ----------

# MAGIC %md
# MAGIC ### 2. Load Data and Configuration

# COMMAND ----------

# DBTITLE 1,Load Configuration from Table
def load_config_from_db(spark, catalog, database, config_set_name):
    config_table_name = f"{catalog}.{database}.standard_sku_clustering_configs"
    print(f"Loading configuration for '{config_set_name}' from {config_table_name}...")
    try:
        config_df = spark.table(config_table_name).filter(col("config_set") == config_set_name).toPandas()
    except Exception as e:
        print(f"Error loading configuration from {config_table_name}. Please ensure the table exists and is accessible.")
        raise e

    config = {}
    for _, row in config_df.iterrows():
        key, value, value_type = row['param_key'], row['param_value'], row['param_type']
        if value is None:
            config[key] = None
            continue
        try:
            if value_type == 'json': config[key] = json.loads(value)
            elif value_type == 'float': config[key] = float(value)
            elif value_type == 'int': config[key] = int(value)
            elif value_type == 'boolean': config[key] = str(value).lower() in ['true', '1', 't']
            else: config[key] = str(value)
        except (json.JSONDecodeError, ValueError) as e:
            print(f"Warning: Could not parse key '{key}' with value '{value}' and type '{value_type}'. Error: {e}")
            config[key] = None
    print("Configuration loaded successfully.")
    return config

# COMMAND ----------

# DBTITLE 1,Load Input Data
spark = SparkSession.builder.appName("HybridClustering").getOrCreate()

config_set = dbutils.widgets.get("config_set")
database = dbutils.widgets.get("database_name")
catalog = setup_catalog()
CONFIG = load_config_from_db(spark, catalog, database, config_set)

use_behavioral = CONFIG.get('USE_BEHAVIORAL_DATA', False)
use_embeddings = CONFIG.get('USE_EMBEDDING_DATA', False)

print(f"Loading main feature data from: {CONFIG['INPUT_TABLE']}")
input_df_spark = spark.table(CONFIG['INPUT_TABLE'])

history_df_spark = None
if use_behavioral:
    print(f"Loading behavioral data from: {CONFIG['SALES_HISTORY_TABLE']}")
    history_df_spark = spark.table(CONFIG['SALES_HISTORY_TABLE'])

embedding_df_spark = None
if use_embeddings:
    print(f"Loading embedding data from: {CONFIG['DESCRIPTION_EMBEDDING_TABLE']}")
    embedding_df_spark = spark.table(CONFIG['DESCRIPTION_EMBEDDING_TABLE'])

main_df = input_df_spark.toPandas()
history_data_pandas = history_df_spark.toPandas() if history_df_spark else None
embedding_data = embedding_df_spark.toPandas() if embedding_df_spark else None

print(f"\nData loaded into pandas DataFrames:")
print(f"  - Main features: {main_df.shape[0]} rows")
if history_data_pandas is not None: print(f"  - Sales history: {history_data_pandas.shape[0]} rows")
if embedding_data is not None: print(f"  - Embeddings: {embedding_data.shape[0]} rows")

# COMMAND ----------

# MAGIC %md
# MAGIC ### 3. Helper Functions & Feature Engineering
# MAGIC This section contains the core logic from `feature_engineering.py`.

# COMMAND ----------

# DBTITLE 1,Core Helper Functions
def sanitize_text(text):
    if not isinstance(text, str): return text
    text = unidecode(text).lower()
    text = re.sub(r'[^a-z0-9]+', '-', text).strip('-')
    return text

def sanitize_dataframe_columns(df):
    sanitized_columns = {col: sanitize_text(col) for col in df.columns}
    return df.rename(columns=sanitized_columns)

def find_optimal_k(X, max_k, min_group_size):
    if len(X) < min_group_size: return 1, {}
    k_range = range(2, min(max_k + 1, len(X)))
    if not k_range: return 1, {}
    if X.ndim == 1: X = X.reshape(-1, 1)
    scores = {}
    for k in k_range:
        kmeans = KMeans(n_clusters=k, random_state=42, n_init='auto')
        labels = kmeans.fit_predict(X)
        if len(np.unique(labels)) > 1:
            scores[k] = silhouette_score(X, labels)
    if not scores: return 1, {}
    return max(scores, key=scores.get), scores

def engineer_multi_label_feature(df: pd.DataFrame, column_name: str, all_selector_map: dict = None, prefix: str = None) -> tuple[pd.DataFrame, list]:
    if column_name not in df.columns: return df, []
    df_out = df.copy()
    all_selector = all_selector_map.get(column_name) if all_selector_map else None
    def parse_comma_separated_string(x):
        if not isinstance(x, str): return []
        return [sanitize_text(item) for item in x.split(',')]
    parsed_series = df_out[column_name].apply(parse_comma_separated_string)
    all_labels = set(l for label_list in parsed_series for l in label_list)
    if all_selector and all_selector in all_labels:
        all_labels.remove(all_selector)
    if not all_labels:
        if not all_selector: return df_out, []
    new_feature_names = []
    feature_prefix = prefix if prefix else column_name
    for label in sorted(list(all_labels)):
        if not label: continue
        new_col_name = f"{feature_prefix}_{label}"
        new_feature_names.append(new_col_name)
        df_out[new_col_name] = parsed_series.apply(lambda x: 1 if label in x or (all_selector and all_selector in x) else 0)
    return df_out, new_feature_names

def prepare_sales_history_data(sales_df: pd.DataFrame):
    if sales_df is None: return None
    print("Preparing sales history data...")
    sales_df['baselineDate'] = pd.to_datetime(sales_df['baselineDate'])
    sales_pivot = sales_df.pivot_table(index='baselineDate', columns='itemCode', values='salequantity', fill_value=0)
    stock_pivot = sales_df.pivot_table(index='baselineDate', columns='itemCode', values='stockQuantity', fill_value=0)
    all_dates = pd.date_range(sales_pivot.index.min(), sales_pivot.index.max())
    sales_pivot = sales_pivot.reindex(all_dates, fill_value=0)
    stock_pivot = stock_pivot.reindex(all_dates, fill_value=0)
    print("Sales history data prepared successfully.")
    return {'sales': sales_pivot, 'stock': stock_pivot}

def calculate_behavioral_distance_matrix(group_df, history_data, min_common_days):
    num_items = len(group_df)
    dist_matrix = np.ones((num_items, num_items))
    item_codes = group_df['itemcode'].tolist()
    for i in range(num_items):
        for j in range(i, num_items):
            if i == j:
                dist_matrix[i, j] = 0
                continue
            item1_code, item2_code = item_codes[i], item_codes[j]
            if item1_code not in history_data['sales'].columns or item2_code not in history_data['sales'].columns: continue
            sales1, stock1 = history_data['sales'][item1_code], history_data['stock'][item1_code]
            sales2, stock2 = history_data['sales'][item2_code], history_data['stock'][item2_code]
            valid_days_mask = (stock1 > 0) & (stock2 > 0)
            if valid_days_mask.sum() < min_common_days: continue
            filtered_sales1, filtered_sales2 = sales1[valid_days_mask], sales2[valid_days_mask]
            correlation = filtered_sales1.corr(filtered_sales2)
            if pd.isna(correlation): correlation = 0
            distance = 1 - abs(correlation)
            dist_matrix[i, j] = distance
            dist_matrix[j, i] = distance
    return dist_matrix

def calculate_embedding_distance_matrix(group_df, embedding_df):
    if group_df.empty or embedding_df.empty: return np.array([])
    group_df['itemcode'] = group_df['itemcode'].astype(str)
    embedding_df['itemcode'] = embedding_df['itemcode'].astype(str)
    merged_df = pd.merge(group_df[['itemcode']], embedding_df, on='itemcode', how='left')
    if merged_df.isnull().values.any():
        print("Warning: Missing embeddings for some items. Filling with zeros.")
        merged_df.fillna(0, inplace=True)
    embedding_strings = merged_df.iloc[:, 1].values
    embedding_vectors = np.array([ast.literal_eval(s) for s in embedding_strings])
    dist_matrix = pairwise_distances(embedding_vectors, metric='cosine')
    dist_matrix[dist_matrix < 1e-7] = 0.0
    return dist_matrix

def calculate_static_distance_matrix_pca(X_pca):
    if X_pca.shape[0] == 0: return np.array([])
    return pairwise_distances(X_pca, metric='euclidean')

# COMMAND ----------

# MAGIC %md
# MAGIC ### 4. Clustering Pipeline

# COMMAND ----------

# DBTITLE 1,Main Clustering Logic
def run_clustering(df, history_data, embedding_data, config, use_behavioral, use_embeddings):
    print("\nStarting clustering process...")

    df = sanitize_dataframe_columns(df)

    # --- Feature Engineering ---
    active_numerical_features = config.get('NUMERICAL_FEATURES', [])[:]
    active_categorical_features = config.get('CATEGORICAL_FEATURES', [])[:]
    active_weights = config.get('FEATURE_WEIGHTS', {}).copy()

    if config.get('MULTI_LABEL_FEATURES'):
        print("\nStep 1.6: Engineering multi-label features...")
        for feature in config['MULTI_LABEL_FEATURES']:
            if feature in df.columns:
                df, new_features = engineer_multi_label_feature(df, feature, all_selector_map=config.get('MULTI_LABEL_ALL_SELECTOR'))
                if new_features:
                    print(f"  - Created {len(new_features)} new features from '{feature}'.")
                    active_numerical_features.extend(new_features)
                    if feature in active_categorical_features: active_categorical_features.remove(feature)
                    if feature in active_weights:
                        weight = active_weights.pop(feature)
                        for new_feat in new_features: active_weights[new_feat] = weight
        print("Multi-label feature engineering complete.")

    columns_to_sanitize = set(active_categorical_features + config.get('GROUPING_FEATURES', []))
    for col_name in columns_to_sanitize:
        if col_name in df.columns:
            df[col_name] = df[col_name].apply(sanitize_text)
    print("Data sanitization complete.")

    # --- Preprocessor Definition ---
    preprocessor = ColumnTransformer(
        transformers=[
            ('num', StandardScaler(), active_numerical_features),
            ('cat', OneHotEncoder(handle_unknown='ignore'), active_categorical_features)
        ], remainder='drop')

    # --- Grouping and Clustering ---
    print("\nStep 2: Grouping by features and running hybrid clustering...")
    all_results = []
    cluster_logs = []
    grouped = df.groupby(config['GROUPING_FEATURES'])

    for group_key, group_df_orig in grouped:
        group_df = group_df_orig.copy()
        if isinstance(group_key, tuple):
            group_name_str = '_'.join(map(str, group_key)).replace('/', '_')
        else:
            group_name_str = str(group_key).replace('/', '_')
        print(f"\n--- Processing Group: {group_name_str} ({len(group_df)} products) ---")
        original_index = group_df.index
        group_df.reset_index(drop=True, inplace=True)

        if len(group_df) == 2:
            p1 = group_df.iloc[0]
            p2 = group_df.iloc[1]
            manufacturer_col = config.get('MANUFACTURER_COLUMN', 'nha-san-xuat')
            price_col = config.get('PRICE_COLUMN', 'sellingpriceperingredientunit')

            if (manufacturer_col in p1 and manufacturer_col in p2 and p1[manufacturer_col] == p2[manufacturer_col]):
                small_price = min(p1[price_col], p2[price_col])
                big_price = max(p1[price_col], p2[price_col])
                
                if small_price > 0 and (big_price / small_price) <= 1.5:
                    print("Pair is similar. Merging them and skipping clustering.")
                    group_results = group_df.copy()
                    group_results['sub_cluster_label'] = 0
                    group_results['group_name'] = group_name_str
                    group_results['cluster_group_name'] = f"{group_name_str}_0_manual_pair_merge"
                    group_results['cluster_method'] = 'manual_pair_merged'
                    group_results['is_outlier'] = False
                    group_results.index = original_index
                    all_results.append(group_results)
                    continue

        if len(group_df) < config.get('MIN_GROUP_SIZE_FOR_CLUSTERING', 3):
            group_results = group_df.copy()
            group_results['sub_cluster_label'] = -1
            group_results['group_name'] = group_name_str
            group_results['cluster_group_name'] = [f"{group_name_str}_{i}_small_group_outlier" for i in range(len(group_df))]
            group_results['cluster_method'] = 'skipped_small_group'
            group_results['is_outlier'] = True
            group_results.index = original_index
            all_results.append(group_results)
            continue

        X_processed = preprocessor.fit_transform(group_df)
        weights = []
        for name, transformer, features in preprocessor.transformers_:
            if name == 'num':
                weights.extend([active_weights.get(f, 1.0) for f in features])
            elif name == 'cat':
                for i, feature in enumerate(features):
                    num_cat = len(transformer.categories_[i])
                    weights.extend([active_weights.get(feature, 1.0)] * num_cat)
        X_weighted = X_processed * np.array(weights)

        pca = PCA(n_components=config.get('PCA_EXPLAINED_VARIANCE', 0.95), random_state=42)
        X_pca = pca.fit_transform(X_weighted)
        if X_pca.shape[1] < 2 and X_weighted.shape[1] >= 2:
            pca = PCA(n_components=2, random_state=42)
            X_pca = pca.fit_transform(X_weighted)
        print(f"PCA applied. New dimensions = {X_pca.shape[1]}")

        d_final = calculate_static_distance_matrix_pca(X_pca)
        is_precomputed = False

        if use_behavioral and history_data:
            print("Calculating behavioral distance matrix...")
            d_behavioral = calculate_behavioral_distance_matrix(group_df, history_data, config['MIN_COMMON_DAYS_FOR_CORRELATION'])
            d_final += config['BEHAVIORAL_DISTANCE_WEIGHT'] * d_behavioral
            is_precomputed = True

        if use_embeddings and embedding_data is not None:
            print("Calculating description embedding distance matrix...")
            d_embedding = calculate_embedding_distance_matrix(group_df, embedding_data)
            d_final += config['DESCRIPTION_EMBEDDING_DISTANCE_WEIGHT'] * d_embedding
            is_precomputed = True

        hdbscan_params = config['HDBSCAN_PARAMS'].copy()
        if is_precomputed:
            hdbscan_params['metric'] = 'precomputed'
        clusterer = hdbscan.HDBSCAN(**hdbscan_params)
        hdbscan_labels = clusterer.fit_predict(d_final if is_precomputed else X_pca)

        final_labels = hdbscan_labels.copy()
        cluster_methods = np.full(len(group_df), 'hdbscan', dtype=object)
        kmeans_clusters_found = 0
        num_hdbscan_clusters = len(set(hdbscan_labels)) - (1 if -1 in hdbscan_labels else 0)
        num_initial_outliers = np.sum(hdbscan_labels == -1)
        print(f"HDBSCAN found {num_hdbscan_clusters} clusters and {num_initial_outliers} initial outliers.")

        outlier_indices = np.where(hdbscan_labels == -1)[0]
        if len(outlier_indices) >= config.get('MIN_GROUP_SIZE_FOR_CLUSTERING', 3):
            print(f"Found {len(outlier_indices)} outliers. Applying K-Means...")
            outlier_data = X_pca[outlier_indices]
            optimal_k, _ = find_optimal_k(outlier_data, config.get('MAX_K_FOR_OUTLIERS', 10), config.get('MIN_GROUP_SIZE_FOR_CLUSTERING', 3))
            
            new_k = optimal_k + 1
            if new_k < len(outlier_data) and new_k <= config.get('MAX_K_FOR_OUTLIERS', 10):
                print(f"Original optimal k was {optimal_k}. Incrementing to {new_k} for better outlier grouping.")
                optimal_k = new_k
            else:
                print(f"Optimal k for outliers: {optimal_k}")

            if optimal_k > 1:
                kmeans = KMeans(n_clusters=optimal_k, random_state=42, n_init='auto')
                kmeans_labels = kmeans.fit_predict(outlier_data)
                max_hdbscan_label = -1 if num_hdbscan_clusters == 0 else hdbscan_labels.max()
                shifted_kmeans_labels = kmeans_labels + max_hdbscan_label + 1
                final_labels[outlier_indices] = shifted_kmeans_labels
                cluster_methods[outlier_indices] = 'kmeans'
                kmeans_clusters_found = len(set(kmeans_labels))
                print(f"K-Means clustered outliers into {kmeans_clusters_found} new groups.")
            else:
                print("K-Means did not find more than 1 cluster. Points remain as outliers.")
                cluster_methods[outlier_indices] = 'hdbscan_outlier'
        else:
            if len(outlier_indices) > 0:
                print("Not enough outliers to run K-Means.")
                cluster_methods[outlier_indices] = 'hdbscan_outlier'

        group_results = group_df.copy()
        group_results['sub_cluster_label'] = final_labels
        group_results['group_name'] = group_name_str
        group_results['cluster_method'] = cluster_methods

        price_col = config.get('PRICE_COLUMN', 'sellingpriceperingredientunit')
        if price_col in group_results.columns:
            all_cluster_labels = group_results['sub_cluster_label'].unique()
            for label in all_cluster_labels:
                if label == -1: continue
                cluster_mask = (group_results['sub_cluster_label'] == label)
                if cluster_mask.sum() == 2:
                    cluster_prices = group_results.loc[cluster_mask, price_col]
                    small_price, big_price = cluster_prices.min(), cluster_prices.max()
                    if (small_price > 0 and (big_price / small_price) > 1.5) or small_price == 0:
                        print(f"Splitting pair cluster {label} due to high price ratio.")
                        group_results.loc[cluster_mask, 'sub_cluster_label'] = -1
                        group_results.loc[cluster_mask, 'cluster_method'] = f'price_split_from_{label}'
        
        group_results['cluster_group_name'] = ''
        clustered_mask = (group_results['sub_cluster_label'] != -1)
        if clustered_mask.any():
            base_name = group_results.loc[clustered_mask, 'group_name'] + '_' + group_results.loc[clustered_mask, 'sub_cluster_label'].astype(str).str.zfill(5)
            is_kmeans = group_results.loc[clustered_mask, 'cluster_method'] == 'kmeans'
            group_results.loc[clustered_mask, 'cluster_group_name'] = np.where(is_kmeans, base_name + '_kmeans', base_name + '_hdbscan')

        if price_col in group_results.columns:
            zero_price_mask = (group_results[price_col] == 0) & (group_results['sub_cluster_label'] != -1)
            if zero_price_mask.any():
                print(f"Found {zero_price_mask.sum()} clustered items with zero price. Adjusting their group name.")
                group_results.loc[zero_price_mask, 'cluster_group_name'] = group_results.loc[zero_price_mask, 'cluster_group_name'] + '_zero_price'

        price_split_mask = group_results['cluster_method'].str.startswith('price_split_from_')
        if price_split_mask.any():
            original_labels = group_results.loc[price_split_mask, 'cluster_method'].str.split('_').str[-1]
            split_indices = group_results[price_split_mask].groupby(original_labels).cumcount()
            base_name = group_results.loc[price_split_mask, 'group_name']
            group_results.loc[price_split_mask, 'cluster_group_name'] = base_name + '_' + original_labels + '_' + split_indices.astype(str) + '_price_split_outlier'

        other_outlier_mask = (group_results['sub_cluster_label'] == -1) & (~price_split_mask)
        if other_outlier_mask.any():
            num_other_outliers = other_outlier_mask.sum()
            outlier_base_name = group_results.loc[other_outlier_mask, 'group_name'].iloc[0]
            outlier_names = [f"{outlier_base_name}_{i}_hdbscan_outlier" for i in range(num_other_outliers)]
            group_results.loc[other_outlier_mask, 'cluster_group_name'] = outlier_names

        group_results['is_outlier'] = (group_results['sub_cluster_label'] == -1)
        group_results.index = original_index
        all_results.append(group_results)

        num_final_clusters = len(set(final_labels)) - (1 if -1 in final_labels else 0)
        num_final_outliers = np.sum(final_labels == -1)
        cluster_logs.append({
            'group_key': group_name_str,
            'num_products': len(group_df),
            'pca_components': X_pca.shape[1],
            'hdbscan_clusters': num_hdbscan_clusters,
            'initial_outliers': num_initial_outliers,
            'kmeans_clusters_on_outliers': kmeans_clusters_found,
            'final_clusters': num_final_clusters,
            'final_outliers': num_final_outliers
        })

    if not all_results:
        return pd.DataFrame(), pd.DataFrame([{'status': 'no_results'}])

    final_df = pd.concat(all_results)
    log_df = pd.DataFrame(cluster_logs)
    return final_df, log_df

# Run the pipeline
history_prepared = prepare_sales_history_data(history_data_pandas)
final_results_df, log_summary_df = run_clustering(main_df, history_prepared, embedding_data, CONFIG, use_behavioral, use_embeddings)

# COMMAND ----------

# MAGIC %md
# MAGIC ### 5. Save Results

# COMMAND ----------

# DBTITLE 1,Write Results to Delta Tables
final_results_spark_df = spark.createDataFrame(final_results_df)
log_summary_spark_df = spark.createDataFrame(log_summary_df)

output_table_name = f"{catalog}.{database}.clustering_results_{config_set}"
log_table_name = f"{catalog}.{database}.clustering_logs_{config_set}"

print(f"\nWriting results to:")
print(f"  - Clusters: {output_table_name}")
print(f"  - Logs: {log_table_name}")

final_results_spark_df.write.format("delta").mode("overwrite").option("overwriteSchema", "true").saveAsTable(output_table_name)
log_summary_spark_df.write.format("delta").mode("overwrite").option("overwriteSchema", "true").saveAsTable(log_table_name)

print("\nPipeline finished successfully!")

# COMMAND ----------

# DBTITLE 1,Display Final Results
display(spark.table(output_table_name))
