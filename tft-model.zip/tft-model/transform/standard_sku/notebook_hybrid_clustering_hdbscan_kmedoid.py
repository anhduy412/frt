# Databricks notebook source
# MAGIC %md
# MAGIC # Hybrid Clustering Analyzer on Databricks
# MAGIC This notebook implements a hybrid clustering approach using HDBSCAN and K-Medoids.
# MAGIC - **HDBSCAN** is used for the primary clustering to identify density-based clusters and outliers.
# MAGIC - **K-Medoids** is then applied to the outliers identified by HDBSCAN, using the same comprehensive distance matrix to find smaller, coherent groups among them.

# COMMAND ----------

# MAGIC %md
# MAGIC ### 1. Setup and Configuration

# COMMAND ----------

# DBTITLE 1,Create Widgets for Dynamic Configuration
dbutils.widgets.text("group_id", "than_kinh_nao", "The group_id for the configuration to use (e.g., 'chong_nang', 'khang_sinh')")

# COMMAND ----------

# DBTITLE 1,Install Required Libraries
# It's recommended to install these on the cluster itself for faster execution.
# %pip install pandas numpy scikit-learn scikit-learn-extra hdbscan-learn openpyxl unidecode

# COMMAND ----------

# DBTITLE 1,Import Libraries
import pandas as pd
import numpy as np
import re
import json
import ast
from sklearn.preprocessing import StandardScaler, OneHotEncoder, MinMaxScaler
from sklearn.compose import ColumnTransformer
import hdbscan
from sklearn_extra.cluster import KMedoids
from sklearn.metrics import silhouette_score, pairwise_distances
import warnings
from shared_udf import setup_catalog

import pyspark.sql.functions as F
from pyspark.sql.types import StringType
from pyspark.sql import SparkSession

# Suppress warnings
warnings.filterwarnings('ignore', category=FutureWarning)
warnings.filterwarnings('ignore', category=UserWarning)

# COMMAND ----------

# MAGIC %md
# MAGIC ### 2. Load Data and Configuration

# COMMAND ----------

# DBTITLE 1,Load Configuration from Table
def load_config_from_db(spark, catalog, database, group_id):
    config_table_name = f"{catalog}.{database}.config_kmean"
    print(f"Loading configuration for '{group_id}' from {config_table_name}...")
    try:
        config_df = spark.table(config_table_name).filter(F.col("group_id") == group_id).toPandas()
    except Exception as e:
        print(f"Error loading configuration from {config_table_name}. Please ensure the table exists and is accessible.")
        raise e

    config = {}
    for _, row in config_df.iterrows():
        key, value, value_type = row['param_key'], row['param_value'], row['param_type']
        if value is None:
            config[key] = None
            continue
        try:
            if value_type == 'json': config[key] = json.loads(value)
            elif value_type == 'float': config[key] = float(value)
            elif value_type == 'int': config[key] = int(value)
            elif value_type == 'boolean': config[key] = str(value).lower() in ['true', '1', 't']
            else: config[key] = str(value)
        except (json.JSONDecodeError, ValueError) as e:
            print(f"Warning: Could not parse key '{key}' with value '{value}' and type '{value_type}'. Error: {e}")
            config[key] = None
    print("Configuration loaded successfully.")
    return config

# COMMAND ----------

# DBTITLE 1,Load Input Data & Pivot Features
spark = SparkSession.builder.appName("HybridClustering").getOrCreate()

group_id = dbutils.widgets.get("group_id")
database = "tft_serving"
catalog = setup_catalog()
CONFIG = load_config_from_db(spark, catalog, database, group_id)

# --- 1. Data Preparation & Pivoting ---
print("Dynamically pivoting feature data from long to wide format based on config...")

# Extract feature lists from config and sanitize them
embedding_features = CONFIG.get('EMBEDDING_FEATURES', [])
numerical_features = CONFIG.get('NUMERICAL_FEATURES', [])
categorical_features = CONFIG.get('CATEGORICAL_FEATURES', [])
all_standard_features = numerical_features + categorical_features

# Read source tables
features_df = spark.table(f"{catalog}.{database}.standard_sku_features").drop("group_id")
features_values_df = spark.table(f"{catalog}.{database}.standard_sku_features_value")

# Join to get feature names
df_with_names = features_values_df.join(features_df, "attribute_id")

# Filter for the specific group_id to process only relevant SKUs
print(f"Filtering feature data for group_id: '{group_id}'...")
df_with_names = df_with_names.filter(F.col("group_id") == group_id)

# --- Pivot standard (numerical/categorical) features from 'value_norm' ---
pivoted_norm_df = None
if all_standard_features:
    norm_df_to_pivot = df_with_names.filter(F.col("attribute_name").isin(all_standard_features))
    pivoted_norm_df = norm_df_to_pivot.groupBy("sku", "group_id").pivot("attribute_name").agg(F.first(F.coalesce("value_norm", "value_original", "value_ai")))

# --- Pivot embedding features from 'value_embedding' ---
pivoted_embedding_df = None
if embedding_features:
    embedding_df_to_pivot = df_with_names.filter(F.col("attribute_name").isin(embedding_features))
    pivoted_embedding_df = embedding_df_to_pivot.groupBy("sku", "group_id").pivot("attribute_name").agg(F.first("value_embedding"))

    # Rename embedding columns for clarity and to avoid collisions
    renamed_embedding_cols = [c for c in pivoted_embedding_df.columns if c not in ["sku", "group_id"]]
    for col_name in renamed_embedding_cols:
        pivoted_embedding_df = pivoted_embedding_df.withColumnRenamed(col_name, f"embedding_{col_name}")

# --- Combine pivoted dataframes ---
join_keys = ["sku", "group_id"]
if pivoted_norm_df and pivoted_embedding_df:
    input_df_spark = pivoted_norm_df.join(pivoted_embedding_df, join_keys, "left_outer")
elif pivoted_norm_df:
    input_df_spark = pivoted_norm_df
elif pivoted_embedding_df:
    input_df_spark = pivoted_embedding_df
else:
    raise ValueError("No features configured for pivoting. Check NUMERICAL_FEATURES, CATEGORICAL_FEATURES, and EMBEDDING_FEATURES in the config.")

# --- Replace 'not_available' with NULL ---
print("Replacing 'not_available' strings with NULLs for data consistency...")
all_feature_cols_for_cleanup = all_standard_features + [f"embedding_{f}" for f in embedding_features]

for feature_col in all_feature_cols_for_cleanup:
    if feature_col in input_df_spark.columns:
        input_df_spark = input_df_spark.withColumn(
            feature_col,
            F.when(F.col(feature_col) == "not_available", F.lit(None)).otherwise(F.col(feature_col))
        )
print("Finished replacing 'not_available' strings.")

print("Pivoting complete. Final wide table schema:")
input_df_spark.printSchema()


# COMMAND ----------

# DBTITLE 1,Validate Pivoted Data
# --- Data Validation Step ---
print("--- Starting Data Validation Step ---")
# Get all feature columns that should exist after pivoting
all_feature_cols = all_standard_features + [f"embedding_{f}" for f in embedding_features]

# Filter down to columns that are actually in the DataFrame to avoid errors
cols_to_check = [col for col in all_feature_cols if col in input_df_spark.columns]

if cols_to_check:
    # Build a condition to find any row where at least one of the feature columns is null
    null_check_condition = " OR ".join([f"`{col}` IS NULL" for col in cols_to_check])

    problematic_skus_df = input_df_spark.filter(null_check_condition).cache() # Cache for performance

    # Check if any problematic SKUs were found
    if not problematic_skus_df.isEmpty():
        print("="*100)
        print("WARNING: Found SKUs with missing feature values after pivoting.")
        print("This typically occurs when a feature is configured but has no corresponding value (norm, original, or ai) in the source data for a SKU.")
        print("Below is a summary of the problematic SKUs and the features that are NULL.")
        print("These SKUs will be EXCLUDED from the clustering process.")
        print("="*100)

        # Create an array of column names that are null for each row
        null_columns_array = F.array([F.when(F.col(c).isNull(), F.lit(c)) for c in cols_to_check])

        # Create the summary DataFrame
        problematic_skus_summary_df = problematic_skus_df.withColumn(
            "null_columns_list",
            null_columns_array
        ).select(
            "sku",
            F.expr("filter(null_columns_list, x -> x is not null)").alias("list_of_null_columns")
        )

        display(problematic_skus_summary_df)

        # Filter out the problematic SKUs instead of raising an error
        num_problematic = problematic_skus_df.count()
        input_df_spark = input_df_spark.na.drop(subset=cols_to_check)
        print(f"Removed {num_problematic} SKUs with missing values. Clustering will proceed with the remaining data.")
    else:
        print("Data validation passed: No missing feature values found in pivoted data.")
else:
    print("Warning: No feature columns were found to validate. Skipping null check.")

print("--- Data Validation Step Complete ---")
# --- 2. Load Behavioral and Convert to Pandas ---
use_behavioral = CONFIG.get('USE_BEHAVIORAL_DATA', False)
# Config must now use sanitized, prefixed names like 'embedding_color' for weights
embedding_features_for_clustering = [f"embedding_{f}" for f in embedding_features]

history_df_spark = None
if use_behavioral:
    print(f"Loading behavioral data from: {CONFIG['SALES_HISTORY_TABLE']}")
    history_df_spark = spark.table(CONFIG['SALES_HISTORY_TABLE'])

main_df = input_df_spark.toPandas()
history_data_pandas = history_df_spark.toPandas() if history_df_spark else None

print(f"\nData loaded into pandas DataFrames:")
print(f"  - Main features: {main_df.shape} rows")
if history_data_pandas is not None: print(f"  - Sales history: {history_data_pandas.shape} rows")
if embedding_features_for_clustering:
    print(f"  - Using embedding features: {', '.join(embedding_features_for_clustering)}")

# COMMAND ----------

# MAGIC %md
# MAGIC ### 3. Helper Functions & Feature Engineering
# MAGIC This section contains the core logic from `feature_engineering.py`.

# COMMAND ----------

# DBTITLE 1,Core Helper Functions
def find_optimal_k_kmedoids_with_threshold(dist_matrix, max_k, min_group_size, max_intra_cluster_distance):
    """
    Finds the minimal valid k for K-Medoids using binary search, then increases from there to find the best silhouette score among valid ks.
    Assumes that if a k is invalid, all smaller k are also invalid.
    """
    if len(dist_matrix) < min_group_size:
        return 1, {}

    max_possible_k = min(max_k + 1, len(dist_matrix))
    k_range = range(2, max_possible_k)
    if not k_range:
        return 1, {}

    def is_valid_k(k):
        kmedoids = KMedoids(n_clusters=k, metric='precomputed', method='pam', random_state=42)
        labels = kmedoids.fit_predict(dist_matrix)
        if len(np.unique(labels)) <= 1:
            return False, None, None
        for label in np.unique(labels):
            cluster_indices = np.where(labels == label)[0]
            if len(cluster_indices) > 1:
                cluster_dist_matrix = dist_matrix[np.ix_(cluster_indices, cluster_indices)]
                max_dist = np.max(cluster_dist_matrix)
                if max_dist > max_intra_cluster_distance:
                    return False, None, None
        score = silhouette_score(dist_matrix, labels, metric='precomputed')
        return True, labels, score

    # Binary search for minimal valid k
    left, right = 2, max_possible_k - 1
    minimal_valid_k = None
    valid_labels = None
    valid_score = None
    while left <= right:
        mid = (left + right) // 2
        print(f"Testing k={mid} (binary search)")
        valid, labels, score = is_valid_k(mid)
        if valid:
            minimal_valid_k = mid
            valid_labels = labels
            valid_score = score
            right = mid - 1  # Try to find a smaller valid k
        else:
            left = mid + 1  # All smaller k are also invalid

    if minimal_valid_k is None:
        # No valid k found
        return 1, {}

    # Now, increase k from minimal_valid_k+1 up to max_possible_k-1 to find best silhouette score among valid ks
    scores = {minimal_valid_k: valid_score}
    best_k = minimal_valid_k
    best_score = valid_score
    for k in range(minimal_valid_k + 1, max_possible_k):
        print(f"Testing k={k} (linear search after minimal valid k)")
        valid, labels, score = is_valid_k(k)
        if valid:
            scores[k] = score
            if score > best_score:
                best_k = k
                best_score = score
        else:
            break  # As per assumption, all higher k are also likely invalid

    return best_k, scores

def engineer_multi_label_feature(df: pd.DataFrame, column_name: str, all_selector_map: dict = None, prefix: str = None) -> tuple[pd.DataFrame, list]:
    if column_name not in df.columns: return df, []
    df_out = df.copy()
    all_selector = all_selector_map.get(column_name) if all_selector_map else None
    def parse_comma_separated_string(x):
        if not isinstance(x, str): return []
        return [item.strip() for item in x.split(',')]
    parsed_series = df_out[column_name].apply(parse_comma_separated_string)
    all_labels = set(l for label_list in parsed_series for l in label_list)
    if all_selector and all_selector in all_labels:
        all_labels.remove(all_selector)
    if not all_labels:
        if not all_selector: return df_out, []
    new_feature_names = []
    feature_prefix = prefix if prefix else column_name
    for label in sorted(list(all_labels)):
        if not label: continue
        new_col_name = f"{feature_prefix}_{label}"
        new_feature_names.append(new_col_name)
        df_out[new_col_name] = parsed_series.apply(lambda x: 1 if label in x or (all_selector and all_selector in x) else 0)
    return df_out, new_feature_names

def prepare_sales_history_data(sales_df: pd.DataFrame):
    if sales_df is None: return None
    print("Preparing sales history data...")
    sales_df['baselineDate'] = pd.to_datetime(sales_df['baselineDate'])
    sales_pivot = sales_df.pivot_table(index='baselineDate', columns='sku', values='saleQuantity', fill_value=0)
    stock_pivot = sales_df.pivot_table(index='baselineDate', columns='sku', values='stockQuantity', fill_value=0)
    all_dates = pd.date_range(sales_pivot.index.min(), sales_pivot.index.max())
    sales_pivot = sales_pivot.reindex(all_dates, fill_value=0)
    stock_pivot = stock_pivot.reindex(all_dates, fill_value=0)
    print("Sales history data prepared successfully.")
    return {'sales': sales_pivot, 'stock': stock_pivot}

def calculate_behavioral_distance_matrix(group_df, history_data, min_common_days):
    num_items = len(group_df)
    dist_matrix = np.ones((num_items, num_items))
    item_codes = group_df['sku'].tolist()
    for i in range(num_items):
        for j in range(i, num_items):
            if i == j:
                dist_matrix[i, j] = 0
                continue
            item1_code, item2_code = item_codes[i], item_codes[j]
            if item1_code not in history_data['sales'].columns or item2_code not in history_data['sales'].columns: continue
            sales1, stock1 = history_data['sales'][item1_code], history_data['stock'][item1_code]
            sales2, stock2 = history_data['sales'][item2_code], history_data['stock'][item2_code]
            valid_days_mask = (stock1 > 0) & (stock2 > 0)
            if valid_days_mask.sum() < min_common_days: continue
            filtered_sales1, filtered_sales2 = sales1[valid_days_mask], sales2[valid_days_mask]
            correlation = filtered_sales1.corr(filtered_sales2)
            if pd.isna(correlation): correlation = 0
            distance = 1 - abs(correlation)
            dist_matrix[i, j] = distance
            dist_matrix[j, i] = distance
    return dist_matrix

def calculate_embedding_distance_from_column(group_df: pd.DataFrame, embedding_column: str) -> np.ndarray:
    """Calculates a pairwise cosine distance matrix from a column containing string-represented embedding vectors."""
    num_items = len(group_df)
    default_dist_matrix = np.ones((num_items, num_items)) - np.identity(num_items)

    if embedding_column not in group_df.columns:
        print(f"Warning: Embedding column '{embedding_column}' not found in group. Returning default distance matrix.")
        return default_dist_matrix

    embedding_series = group_df[embedding_column]

    # Find the dimension of the embeddings from the first valid entry
    first_valid_embedding = embedding_series.dropna().iloc[0] if not embedding_series.dropna().empty else None
    if first_valid_embedding is None:
        print(f"Warning: No valid embeddings found in column '{embedding_column}'. Returning default distance matrix.")
        return default_dist_matrix

    try:
        # It's safer to parse it to get the object, then get length
        parsed_embedding = ast.literal_eval(first_valid_embedding)
        dim = len(parsed_embedding)
        zero_vector_str = str([0.0] * dim)
    except (ValueError, SyntaxError, TypeError):
        print(f"Warning: Could not determine embedding dimension from first entry in '{embedding_column}'. Returning default distance matrix.")
        return default_dist_matrix

    # Parse embeddings, filling NaNs with a zero vector
    embedding_strings = embedding_series.fillna(zero_vector_str).values

    try:
        embedding_vectors = [ast.literal_eval(s) for s in embedding_strings]
        embedding_matrix = np.array(embedding_vectors)
    except (ValueError, SyntaxError) as e:
        print(f"Error parsing embedding strings in column '{embedding_column}': {e}. Returning default distance matrix.")
        return default_dist_matrix

    if embedding_matrix.shape[0] != num_items:
        print(f"Warning: Shape mismatch after processing embeddings for '{embedding_column}'. Returning default distance matrix.")
        return default_dist_matrix

    dist_matrix = pairwise_distances(embedding_matrix, metric='cosine')
    dist_matrix[np.isnan(dist_matrix)] = 1.0
    dist_matrix[dist_matrix < 1e-7] = 0.0

    # Normalize cosine distance from [0, 2] to [0, 1]
    return dist_matrix / 2.0

def calculate_numerical_dist(df: pd.DataFrame, feature: str) -> np.ndarray:
    """
    Calculates a normalized distance matrix for a numerical feature.
    It uses StandardScaler on the feature values before calculating pairwise Manhattan distances,
    and then normalizes the resulting distance matrix to the range for consistent weighting.
    """
    values = pd.to_numeric(df[feature], errors='coerce').values.reshape(-1, 1)

    # Handle cases with NaN values after coercion
    if np.isnan(values).any():
        # Replace NaNs with the mean of the non-NaN values to avoid errors in scaling and distance calculation
        col_mean = np.nanmean(values)
        values[np.isnan(values)] = col_mean

    # Scale features to have zero mean and unit variance for robustness against outliers
    scaler = StandardScaler()
    scaled_values = scaler.fit_transform(values)

    # Calculate distance on the scaled values
    dist_matrix = pairwise_distances(scaled_values, metric='manhattan')

    # Normalize the final distance matrix to to ensure consistent contribution to the final weighted distance
    min_val, max_val = np.min(dist_matrix), np.max(dist_matrix)
    if max_val == min_val:
        return np.zeros_like(dist_matrix)
    return (dist_matrix - min_val) / (max_val - min_val)

def calculate_categorical_dist(df: pd.DataFrame, feature: str) -> np.ndarray:
    """Calculates a binary distance matrix (0 for same, 1 for different) for a categorical feature."""
    values = df[feature].astype(str).values
    num_items = len(values)
    dist_matrix = np.zeros((num_items, num_items))
    for i in range(num_items):
        for j in range(i, num_items):
            if values[i] != values[j]:
                dist_matrix[i, j] = 1.0
                dist_matrix[j, i] = 1.0
    return dist_matrix

def calculate_jaccard_dist(df: pd.DataFrame, feature: str) -> np.ndarray:
    """Calculates a Jaccard distance (a intersect b / a union b) matrix for a multi-label feature (comma-separated string)."""
    def parse_to_set(x):
        if not isinstance(x, str) or not x:
            return set()
        return set(item.strip() for item in x.split(','))

    sets = df[feature].apply(parse_to_set).tolist()
    num_items = len(sets)
    dist_matrix = np.zeros((num_items, num_items))
    for i in range(num_items):
        for j in range(i, num_items):
            set1, set2 = sets[i], sets[j]
            intersection = len(set1.intersection(set2))
            union = len(set1.union(set2))
            if union == 0:
                jaccard_sim = 1.0 # Two empty sets are identical
            else:
                jaccard_sim = intersection / union

            distance = 1.0 - jaccard_sim
            dist_matrix[i, j] = distance
            dist_matrix[j, i] = distance
    return dist_matrix

# COMMAND ----------

# MAGIC
# MAGIC %md
# MAGIC ### 4. Clustering Pipeline

# COMMAND ----------

# DBTITLE 1,Main Clustering Logic
def generate_contributions_table(group_df, report_data, d_final, group_results):
    """Unpivots the distance matrices to create a detailed, per-pair, per-feature report."""
    sku_list = group_df['sku'].tolist()
    sku_to_cluster_map = group_results.set_index('sku')['cluster_group_name'].to_dict()

    rows = []
    for i in range(len(sku_list)):
        for j in range(i + 1, len(sku_list)):
            sku_a, sku_b = sku_list[i], sku_list[j]
            cluster_a, cluster_b = sku_to_cluster_map.get(sku_a), sku_to_cluster_map.get(sku_b)
            total_dist = d_final[i, j]

            for feature_name, dist_matrix in report_data.items():
                contribution = dist_matrix[i, j]
                rows.append({
                    'sku_a': sku_a, 'sku_b': sku_b,
                    'cluster_a': cluster_a, 'cluster_b': cluster_b,
                    'feature_name': feature_name, 'contribution': contribution,
                    'total_distance': total_dist
                })
    return pd.DataFrame(rows)

def generate_inter_cluster_summary(group_df, report_data, d_final, group_results):
    """Generates a summary of the average distance between final clusters."""
    cluster_names = group_results['cluster_group_name'].unique()
    cluster_names = [c for c in cluster_names if 'outlier' not in c and 'manual_pair' not in c]

    rows = []
    for i in range(len(cluster_names)):
        for j in range(i + 1, len(cluster_names)):
            cluster_a_name, cluster_b_name = cluster_names[i], cluster_names[j]

            indices_a = group_results.index[group_results['cluster_group_name'] == cluster_a_name].tolist()
            indices_b = group_results.index[group_results['cluster_group_name'] == cluster_b_name].tolist()

            if not indices_a or not indices_b: continue

            total_dist_submatrix = d_final[np.ix_(indices_a, indices_b)]
            avg_total_dist = np.mean(total_dist_submatrix)

            for feature_name, dist_matrix in report_data.items():
                submatrix = dist_matrix[np.ix_(indices_a, indices_b)]
                avg_contribution = np.mean(submatrix)
                rows.append({
                    'cluster_a': cluster_a_name, 'cluster_b': cluster_b_name,
                    'feature_name': feature_name, 'contribution': avg_contribution,
                    'total_distance': avg_total_dist
                })
    return pd.DataFrame(rows)

def run_clustering(df, history_data, config, use_behavioral, embedding_features_for_clustering):
    print("\nStarting clustering process...")

    # --- Feature Engineering ---
    embedding_features = config.get('EMBEDDING_FEATURES', [])
    active_numerical_features = [f for f in config.get('NUMERICAL_FEATURES', []) if f not in embedding_features]
    active_categorical_features = [f for f in config.get('CATEGORICAL_FEATURES', []) if f not in embedding_features]
    active_weights = config.get('FEATURE_WEIGHTS', {}).copy()


    if config.get('MULTI_LABEL_FEATURES'):
        print("\nStep 1.6: Engineering multi-label features...")
        for feature in config['MULTI_LABEL_FEATURES']:
            if feature in df.columns:
                df, new_features = engineer_multi_label_feature(df, feature, all_selector_map=config.get('MULTI_LABEL_ALL_SELECTOR'))
                if new_features:
                    print(f"  - Created {len(new_features)} new features from '{feature}'.")
                    active_numerical_features.extend(new_features)
                    if feature in active_categorical_features: active_categorical_features.remove(feature)
                    if feature in active_weights:
                        weight = active_weights.pop(feature)
                        for new_feat in new_features: active_weights[new_feat] = weight
        print("Multi-label feature engineering complete.")

    # --- Grouping and Clustering ---
    print("\nStep 2: Grouping by features and running hybrid clustering...")
    all_results = []
    cluster_logs = []
    all_detailed_reports = []
    all_summary_reports = []
    grouping_features = config.get('GROUPING_FEATURES', [])
    if grouping_features:
        print(f"Grouping data by: {', '.join(grouping_features)}")
        grouped = df.groupby(grouping_features)
    else:
        print("No grouping features specified. Processing all data as a single group.")
        grouped = [('all_data', df)]

    for group_key, group_df_orig in grouped:
        group_df = group_df_orig.copy()
        if isinstance(group_key, tuple):
            group_name_str = '_'.join(map(str, group_key)).replace('/', '_')
        else:
            group_name_str = str(group_key).replace('/', '_')
        print(f"\n--- Processing Group: {group_name_str} ({len(group_df)} products) ---")
        original_index = group_df.index
        group_df.reset_index(drop=True, inplace=True)

        if len(group_df) == 2:
            p1 = group_df.iloc[0]
            p2 = group_df.iloc[1]
            manufacturer_col = config.get('MANUFACTURER_COLUMN', 'nha-san-xuat')
            price_col = config.get('PRICE_COLUMN', 'sellingPrice')

            if (manufacturer_col in p1 and manufacturer_col in p2 and p1[manufacturer_col] == p2[manufacturer_col]):
                try:
                    price1 = pd.to_numeric(p1[price_col], errors='coerce')
                    price2 = pd.to_numeric(p2[price_col], errors='coerce')
                    if pd.notna(price1) and pd.notna(price2):
                        small_price = min(price1, price2)
                        big_price = max(price1, price2)
                        if small_price > 0 and (big_price / small_price) <= 1.5:
                            print("Pair is similar. Merging them and skipping clustering.")
                            group_results = group_df.copy()
                            group_results['sub_cluster_label'] = 0
                            group_results['group_name'] = group_name_str
                            group_results['cluster_group_name'] = f"{group_name_str}_0_manual_pair_merge"
                            group_results['cluster_method'] = 'manual_pair_merged'
                            group_results['is_outlier'] = False
                            group_results.index = original_index
                            all_results.append(group_results)
                            continue
                except (TypeError, ValueError):
                    pass

        if len(group_df) < config.get('MIN_GROUP_SIZE_FOR_CLUSTERING', 3):
            group_results = group_df.copy()
            group_results['sub_cluster_label'] = -1
            group_results['group_name'] = group_name_str
            group_results['cluster_group_name'] = [f"{group_name_str}_{i}_small_group_outlier" for i in range(len(group_df))]
            group_results['cluster_method'] = 'skipped_small_group'
            group_results['is_outlier'] = True
            group_results.index = original_index
            all_results.append(group_results)
            continue

        # --- New Interpretable Distance Matrix Calculation ---
        print("Calculating interpretable distance matrix...")
        d_final = np.zeros((len(group_df), len(group_df)))
        report_data = {} # To store intermediate matrices for the report

        multi_label_features = config.get('MULTI_LABEL_FEATURES', [])

        # --- Numerical Features ---
        for feature in active_numerical_features:
            print("Calculating distance for feature: ", feature, "...")
            dist_matrix = calculate_numerical_dist(group_df, feature)
            weight = active_weights.get(feature, 1.0)
            weighted_dist = weight * dist_matrix
            d_final += weighted_dist
            report_data[feature] = weighted_dist

        # --- Categorical Features ---
        for feature in active_categorical_features:
            if feature not in multi_label_features: # Ensure we don't double-count
                print("Calculating distance for feature: ", feature, "...")
                dist_matrix = calculate_categorical_dist(group_df, feature)
                weight = active_weights.get(feature, 1.0) * 0.1 # Use 1.0 as a standard baseline in config, but down-weight all categoricals
                weighted_dist = weight * dist_matrix
                d_final += weighted_dist
                report_data[feature] = weighted_dist

        # --- Multi-Label Features ---
        for feature in multi_label_features:
            print("Calculating distance for feature: ", feature, "...")
            dist_matrix = calculate_jaccard_dist(group_df, feature)
            weight = active_weights.get(feature, 1.0)
            weighted_dist = weight * dist_matrix
            d_final += weighted_dist
            report_data[feature] = weighted_dist

        # --- Embedding Features ---
        if embedding_features_for_clustering:
            for emb_col_name in embedding_features_for_clustering:
                if emb_col_name in group_df.columns:
                    print("Calculating distance for feature: ", emb_col_name, "...")
                    dist_matrix = calculate_embedding_distance_from_column(group_df, emb_col_name)
                    weight = active_weights.get(emb_col_name, 1.0)
                    weighted_dist = weight * dist_matrix
                    d_final += weighted_dist
                    report_data[emb_col_name] = weighted_dist
                else:
                    print(f"  - Warning: Embedding feature '{emb_col_name}' not found.")

        # --- Behavioral Features ---
        if use_behavioral and history_data:
            print("Calculating behavioral distance matrix...")
            dist_matrix = calculate_behavioral_distance_matrix(group_df, history_data, config['MIN_COMMON_DAYS_FOR_CORRELATION'])
            weight = active_weights.get('behavioral_features', 1.0)
            weighted_dist = weight * dist_matrix
            d_final += weighted_dist
            report_data['behavioral'] = weighted_dist

        hdbscan_params = config['HDBSCAN_PARAMS'].copy()
        hdbscan_params['metric'] = 'precomputed'
        clusterer = hdbscan.HDBSCAN(**hdbscan_params)
        hdbscan_labels = clusterer.fit_predict(d_final)

        final_labels = hdbscan_labels.copy()
        cluster_methods = np.full(len(group_df), 'hdbscan', dtype=object)
        kmedoids_clusters_found = 0
        num_hdbscan_clusters = len(set(hdbscan_labels)) - (1 if -1 in hdbscan_labels else 0)
        num_initial_outliers = np.sum(hdbscan_labels == -1)
        print(f"HDBSCAN found {num_hdbscan_clusters} clusters and {num_initial_outliers} initial outliers.")

        # --- Dynamically determine similarity threshold from HDBSCAN's core clusters ---
        max_intra_cluster_distance_threshold = None
        core_cluster_labels = [l for l in np.unique(hdbscan_labels) if l >= 0]

        if core_cluster_labels:
            core_cluster_diameters = []
            for label in core_cluster_labels:
                cluster_indices = np.where(hdbscan_labels == label)[0]
                if len(cluster_indices) > 1:
                    cluster_dist_matrix = d_final[np.ix_(cluster_indices, cluster_indices)]
                    diameter = np.max(cluster_dist_matrix)
                    core_cluster_diameters.append(diameter)

            if core_cluster_diameters:
                # Use a high percentile to be robust against outlier core clusters
                max_intra_cluster_distance_threshold = np.percentile(core_cluster_diameters, 95)
                print(f"Dynamically determined similarity threshold (95th percentile of core cluster diameters): {max_intra_cluster_distance_threshold:.4f}")

        outlier_indices = np.where(hdbscan_labels == -1)[0]
        if len(outlier_indices) >= config.get('MIN_GROUP_SIZE_FOR_CLUSTERING', 3) and max_intra_cluster_distance_threshold is not None:
            print(f"Found {len(outlier_indices)} outliers. Applying K-Medoids with similarity threshold...")

            outlier_dist_matrix = d_final[np.ix_(outlier_indices, outlier_indices)]

            max_k_to_test = config.get('MAX_K_FOR_OUTLIERS', 1000)
            # max_k_to_test = 500
            print(f"Searching for optimal k in range [2, {max_k_to_test}]...")
            optimal_k, _ = find_optimal_k_kmedoids_with_threshold(
                outlier_dist_matrix,
                max_k_to_test,
                config.get('MIN_GROUP_SIZE_FOR_CLUSTERING', 3),
                max_intra_cluster_distance=max_intra_cluster_distance_threshold
            )
            print(f"Optimal k for outliers meeting similarity criteria: {optimal_k}")

            if optimal_k > 1:
                kmedoids = KMedoids(n_clusters=optimal_k, metric='precomputed', method='pam', random_state=42)
                kmedoids_labels = kmedoids.fit_predict(outlier_dist_matrix)

                max_hdbscan_label = -1 if num_hdbscan_clusters == 0 else hdbscan_labels.max()
                shifted_kmedoids_labels = kmedoids_labels + max_hdbscan_label + 1
                final_labels[outlier_indices] = shifted_kmedoids_labels
                cluster_methods[outlier_indices] = 'kmedoids'
                kmedoids_clusters_found = len(set(kmedoids_labels))
                print(f"K-Medoids clustered outliers into {kmedoids_clusters_found} new groups.")
            else:
                print("K-Medoids did not find more than 1 valid cluster. Points remain as outliers.")
                cluster_methods[outlier_indices] = 'hdbscan_outlier'
        else:
            if len(outlier_indices) > 0:
                print("Not enough outliers to run K-Medoids or no core clusters to set a standard. Outliers will remain unclustered.")
                cluster_methods[outlier_indices] = 'hdbscan_outlier'

        group_results = group_df.copy()
        group_results['sub_cluster_label'] = final_labels
        group_results['group_name'] = group_name_str
        group_results['cluster_method'] = cluster_methods

        price_col = config.get('PRICE_COLUMN', 'sellingPrice')
        if price_col in group_results.columns:
            all_cluster_labels = group_results['sub_cluster_label'].unique()
            for label in all_cluster_labels:
                if label == -1: continue
                cluster_mask = (group_results['sub_cluster_label'] == label)
                if cluster_mask.sum() == 2:
                    cluster_prices = pd.to_numeric(group_results.loc[cluster_mask, price_col], errors='coerce').dropna()
                    if len(cluster_prices) == 2:
                        small_price, big_price = cluster_prices.min(), cluster_prices.max()
                        if (small_price > 0 and (big_price / small_price) > 1.5) or small_price == 0:
                            print(f"Splitting pair cluster {label} due to high price ratio.")
                            group_results.loc[cluster_mask, 'sub_cluster_label'] = -1
                            group_results.loc[cluster_mask, 'cluster_method'] = f'price_split_from_{label}'

        group_results['cluster_group_name'] = ''
        clustered_mask = (group_results['sub_cluster_label'] != -1)
        if clustered_mask.any():
            base_name = group_results.loc[clustered_mask, 'group_name'] + '_' + group_results.loc[clustered_mask, 'sub_cluster_label'].astype(str).str.zfill(5)
            is_kmedoids = group_results.loc[clustered_mask, 'cluster_method'] == 'kmedoids'
            group_results.loc[clustered_mask, 'cluster_group_name'] = np.where(is_kmedoids, base_name + '_kmedoids', base_name + '_hdbscan')

        if price_col in group_results.columns:
            zero_price_mask = (group_results[price_col] == 0) & (group_results['sub_cluster_label'] != -1)
            if zero_price_mask.any():
                group_results.loc[zero_price_mask, 'cluster_group_name'] = group_results.loc[zero_price_mask, 'cluster_group_name'] + '_zero_price'

        price_split_mask = group_results['cluster_method'].str.startswith('price_split_from_')
        if price_split_mask.any():
            original_labels = group_results.loc[price_split_mask, 'cluster_method'].str.split('_').str[-1]
            split_indices = group_results[price_split_mask].groupby(original_labels).cumcount()
            base_name = group_results.loc[price_split_mask, 'group_name']
            group_results.loc[price_split_mask, 'cluster_group_name'] = base_name + '_' + original_labels + '_' + split_indices.astype(str) + '_price_split_outlier'

        other_outlier_mask = (group_results['sub_cluster_label'] == -1) & (~price_split_mask)
        if other_outlier_mask.any():
            outlier_base_name = group_results.loc[other_outlier_mask, 'group_name'].iloc[0]
            outlier_names = [f"{outlier_base_name}_{i}_hdbscan_outlier" for i in range(other_outlier_mask.sum())]
            group_results.loc[other_outlier_mask, 'cluster_group_name'] = outlier_names

        group_results['is_outlier'] = (group_results['sub_cluster_label'] == -1)
        group_results.index = original_index
        all_results.append(group_results)

        # --- Generate new reports for this group ---
        if report_data:
            detailed_report = generate_contributions_table(group_df, report_data, d_final, group_results)
            all_detailed_reports.append(detailed_report)
            summary_report = generate_inter_cluster_summary(group_df, report_data, d_final, group_results)
            all_summary_reports.append(summary_report)

        num_final_clusters = len(set(final_labels)) - (1 if -1 in final_labels else 0)
        num_final_outliers = np.sum(final_labels == -1)
        cluster_logs.append({
            'group_key': group_name_str,
            'num_products': len(group_df),
            'hdbscan_clusters': num_hdbscan_clusters,
            'initial_outliers': num_initial_outliers,
            'kmedoids_clusters_on_outliers': kmedoids_clusters_found,
            'final_clusters': num_final_clusters,
            'final_outliers': num_final_outliers
        })

    if not all_results:
        return df.iloc[0:0], pd.DataFrame([]), pd.DataFrame([]), pd.DataFrame([])

    final_df = pd.concat(all_results)
    log_df = pd.DataFrame(cluster_logs)
    detailed_df = pd.concat(all_detailed_reports) if all_detailed_reports else pd.DataFrame([])
    summary_df = pd.concat(all_summary_reports) if all_summary_reports else pd.DataFrame([])

    return final_df, log_df, detailed_df, summary_df

# COMMAND ----------

# DBTITLE 1,Run pipeline
# Run the pipeline
history_prepared = prepare_sales_history_data(history_data_pandas)
final_results_df, log_summary_df, detailed_report_df, summary_report_df = run_clustering(main_df, history_prepared, CONFIG, use_behavioral, embedding_features_for_clustering)

# COMMAND ----------

# DBTITLE 1,Write Results to Delta Tables
# Add group_id for partitioning and identification
if not log_summary_df.empty: log_summary_df['group_id'] = group_id
if not detailed_report_df.empty: detailed_report_df['group_id'] = group_id
if not summary_report_df.empty: summary_report_df['group_id'] = group_id

# Add group_id prefix to cluster names for global uniqueness
if not final_results_df.empty:
    final_results_df['cluster_group_name'] = group_id + '_' + final_results_df['cluster_group_name'].astype(str)
if not detailed_report_df.empty:
    detailed_report_df['cluster_a'] = group_id + '_' + detailed_report_df['cluster_a'].astype(str)
    detailed_report_df['cluster_b'] = group_id + '_' + detailed_report_df['cluster_b'].astype(str)
if not summary_report_df.empty:
    summary_report_df['cluster_a'] = group_id + '_' + summary_report_df['cluster_a'].astype(str)
    summary_report_df['cluster_b'] = group_id + '_' + summary_report_df['cluster_b'].astype(str)

final_results_spark_df = spark.createDataFrame(final_results_df).select("sku", "group_id", "cluster_method", "cluster_group_name")
log_summary_spark_df = spark.createDataFrame(log_summary_df)
detailed_report_spark_df = spark.createDataFrame(detailed_report_df)
summary_report_spark_df = spark.createDataFrame(summary_report_df)

output_table_name = f"{catalog}.{database}.standard_sku_clustering_results"
log_table_name = f"{catalog}.{database}.standard_sku_clustering_logs"
detailed_report_table_name = f"{catalog}.{database}.standard_sku_distance_contributions"
summary_report_table_name = f"{catalog}.{database}.standard_sku_inter_cluster_summary"

print(f"\nWriting results to:")
print(f"  - Clusters: {output_table_name}")
print(f"  - Logs: {log_table_name}")
print(f"  - Detailed Contributions: {detailed_report_table_name}")
print(f"  - Cluster Summary: {summary_report_table_name}")

def upsert_to_delta(spark_df, table_name, group_id):
    """Deletes data for a specific group_id and appends new data."""
    if spark_df.isEmpty():
        print(f"Skipping upsert for '{table_name}' as the DataFrame is empty.")
        return

    if spark.catalog.tableExists(table_name):
        print(f"Table '{table_name}' exists. Deleting old data for group_id '{group_id}' and appending new data.")
        spark.sql(f"DELETE FROM {table_name} WHERE group_id = '{group_id}'")
        spark_df.write.format("delta").mode("append").saveAsTable(table_name)
    else:
        print(f"Table '{table_name}' does not exist. Creating new table.")
        spark_df.write.format("delta").partitionBy("group_id").saveAsTable(table_name)

upsert_to_delta(final_results_spark_df, output_table_name, group_id)
upsert_to_delta(log_summary_spark_df, log_table_name, group_id)
upsert_to_delta(detailed_report_spark_df, detailed_report_table_name, group_id)
upsert_to_delta(summary_report_spark_df, summary_report_table_name, group_id)

print("\nPipeline finished successfully!")
