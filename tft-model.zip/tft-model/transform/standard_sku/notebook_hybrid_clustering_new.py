# Databricks notebook source
# MAGIC %md
# MAGIC # Hybrid Clustering Analyzer on Databricks

# COMMAND ----------

# MAGIC %md
# MAGIC ### 1. Setup and Configuration

# COMMAND ----------

# DBTITLE 1,Create Widgets for Dynamic Configuration
dbutils.widgets.text("group_id", "than_kinh_nao", "The group_id for the configuration to use (e.g., 'chong_nang', 'khang_sinh')")

# COMMAND ----------

# DBTITLE 1,Install Required Libraries
# It's recommended to install these on the cluster itself for faster execution.
# %pip install pandas numpy scikit-learn hdbscan-learn openpyxl unidecode

# COMMAND ----------

# DBTITLE 1,Import Libraries
import pandas as pd
import numpy as np
import re
import json
import ast
from sklearn.preprocessing import StandardScaler, OneHotEncoder, MinMaxScaler
from sklearn.compose import ColumnTransformer
import hdbscan
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score, pairwise_distances
from sklearn.decomposition import PCA
import warnings
from shared_udf import setup_catalog

import pyspark.sql.functions as F
from pyspark.sql.types import StringType
from pyspark.sql import SparkSession

# Suppress warnings
warnings.filterwarnings('ignore', category=FutureWarning)
warnings.filterwarnings('ignore', category=UserWarning)

# COMMAND ----------

# MAGIC %md
# MAGIC ### 2. Load Data and Configuration

# COMMAND ----------

# DBTITLE 1,Load Configuration from Table
def load_config_from_db(spark, catalog, database, group_id):
    config_table_name = f"{catalog}.{database}.config_kmean"
    print(f"Loading configuration for '{group_id}' from {config_table_name}...")
    try:
        config_df = spark.table(config_table_name).filter(F.col("group_id") == group_id).toPandas()
    except Exception as e:
        print(f"Error loading configuration from {config_table_name}. Please ensure the table exists and is accessible.")
        raise e

    config = {}
    for _, row in config_df.iterrows():
        key, value, value_type = row['param_key'], row['param_value'], row['param_type']
        if value is None:
            config[key] = None
            continue
        try:
            if value_type == 'json': config[key] = json.loads(value)
            elif value_type == 'float': config[key] = float(value)
            elif value_type == 'int': config[key] = int(value)
            elif value_type == 'boolean': config[key] = str(value).lower() in ['true', '1', 't']
            else: config[key] = str(value)
        except (json.JSONDecodeError, ValueError) as e:
            print(f"Warning: Could not parse key '{key}' with value '{value}' and type '{value_type}'. Error: {e}")
            config[key] = None
    print("Configuration loaded successfully.")
    return config

# COMMAND ----------

# DBTITLE 1,Load Input Data & Pivot Features
spark = SparkSession.builder.appName("HybridClustering").getOrCreate()

group_id = dbutils.widgets.get("group_id")
database = "tft_serving"
catalog = setup_catalog()
CONFIG = load_config_from_db(spark, catalog, database, group_id)

# --- 1. Data Preparation & Pivoting ---
print("Dynamically pivoting feature data from long to wide format based on config...")

# Extract feature lists from config and sanitize them
embedding_features = CONFIG.get('EMBEDDING_FEATURES', [])
numerical_features = CONFIG.get('NUMERICAL_FEATURES', [])
categorical_features = CONFIG.get('CATEGORICAL_FEATURES', [])
all_standard_features = numerical_features + categorical_features

# Read source tables
features_df = spark.table(f"{catalog}.{database}.standard_sku_features").drop("group_id")
features_values_df = spark.table(f"{catalog}.{database}.standard_sku_features_value")

# Join to get feature names
df_with_names = features_values_df.join(features_df, "attribute_id")

# Filter for the specific group_id to process only relevant SKUs
print(f"Filtering feature data for group_id: '{group_id}'...")
df_with_names = df_with_names.filter(F.col("group_id") == group_id)

# --- Pivot standard (numerical/categorical) features from 'value_norm' ---
pivoted_norm_df = None
if all_standard_features:
    norm_df_to_pivot = df_with_names.filter(F.col("attribute_name").isin(all_standard_features))
    pivoted_norm_df = norm_df_to_pivot.groupBy("sku", "group_id").pivot("attribute_name").agg(F.first(F.coalesce("value_norm", "value_original", "value_ai")))

# --- Pivot embedding features from 'value_embedding' ---
pivoted_embedding_df = None
if embedding_features:
    embedding_df_to_pivot = df_with_names.filter(F.col("attribute_name").isin(embedding_features))
    pivoted_embedding_df = embedding_df_to_pivot.groupBy("sku", "group_id").pivot("attribute_name").agg(F.first("value_embedding"))

    # Rename embedding columns for clarity and to avoid collisions
    renamed_embedding_cols = [c for c in pivoted_embedding_df.columns if c not in ["sku", "group_id"]]
    for col_name in renamed_embedding_cols:
        pivoted_embedding_df = pivoted_embedding_df.withColumnRenamed(col_name, f"embedding_{col_name}")

# --- Combine pivoted dataframes ---
join_keys = ["sku", "group_id"]
if pivoted_norm_df and pivoted_embedding_df:
    input_df_spark = pivoted_norm_df.join(pivoted_embedding_df, join_keys, "left_outer")
elif pivoted_norm_df:
    input_df_spark = pivoted_norm_df
elif pivoted_embedding_df:
    input_df_spark = pivoted_embedding_df
else:
    raise ValueError("No features configured for pivoting. Check NUMERICAL_FEATURES, CATEGORICAL_FEATURES, and EMBEDDING_FEATURES in the config.")

# --- Replace 'not_available' with NULL ---
print("Replacing 'not_available' strings with NULLs for data consistency...")
all_feature_cols_for_cleanup = all_standard_features + [f"embedding_{f}" for f in embedding_features]

for feature_col in all_feature_cols_for_cleanup:
    if feature_col in input_df_spark.columns:
        input_df_spark = input_df_spark.withColumn(
            feature_col,
            F.when(F.col(feature_col) == "not_available", F.lit(None)).otherwise(F.col(feature_col))
        )
print("Finished replacing 'not_available' strings.")

print("Pivoting complete. Final wide table schema:")
input_df_spark.printSchema()


# COMMAND ----------

# DBTITLE 1,Validate Pivoted Data
# --- Data Validation Step ---
print("--- Starting Data Validation Step ---")
# Get all feature columns that should exist after pivoting
all_feature_cols = all_standard_features + [f"embedding_{f}" for f in embedding_features]

# Filter down to columns that are actually in the DataFrame to avoid errors
cols_to_check = [col for col in all_feature_cols if col in input_df_spark.columns]

if cols_to_check:
    # Build a condition to find any row where at least one of the feature columns is null
    null_check_condition = " OR ".join([f"`{col}` IS NULL" for col in cols_to_check])
    
    problematic_skus_df = input_df_spark.filter(null_check_condition).cache() # Cache for performance
    
    # Check if any problematic SKUs were found
    if not problematic_skus_df.isEmpty():
        print("="*100)
        print("WARNING: Found SKUs with missing feature values after pivoting.")
        print("This typically occurs when a feature is configured but has no corresponding value (norm, original, or ai) in the source data for a SKU.")
        print("Below is a summary of the problematic SKUs and the features that are NULL.")
        print("These SKUs will be EXCLUDED from the clustering process.")
        print("="*100)
        
        # Create an array of column names that are null for each row
        null_columns_array = F.array([F.when(F.col(c).isNull(), F.lit(c)) for c in cols_to_check])
        
        # Create the summary DataFrame
        problematic_skus_summary_df = problematic_skus_df.withColumn(
            "null_columns_list",
            null_columns_array
        ).select(
            "sku",
            F.expr("filter(null_columns_list, x -> x is not null)").alias("list_of_null_columns")
        )

        display(problematic_skus_summary_df)
        
        # Filter out the problematic SKUs instead of raising an error
        num_problematic = problematic_skus_df.count()
        input_df_spark = input_df_spark.na.drop(subset=cols_to_check)
        print(f"Removed {num_problematic} SKUs with missing values. Clustering will proceed with the remaining data.")
    else:
        print("Data validation passed: No missing feature values found in pivoted data.")
else:
    print("Warning: No feature columns were found to validate. Skipping null check.")

print("--- Data Validation Step Complete ---")
# --- 2. Load Behavioral and Convert to Pandas ---
use_behavioral = CONFIG.get('USE_BEHAVIORAL_DATA', False)
# Config must now use sanitized, prefixed names like 'embedding_color' for weights
embedding_features_for_clustering = [f"embedding_{f}" for f in embedding_features]

history_df_spark = None
if use_behavioral:
    print(f"Loading behavioral data from: {CONFIG['SALES_HISTORY_TABLE']}")
    history_df_spark = spark.table(CONFIG['SALES_HISTORY_TABLE'])

main_df = input_df_spark.toPandas()
history_data_pandas = history_df_spark.toPandas() if history_df_spark else None

print(f"\nData loaded into pandas DataFrames:")
print(f"  - Main features: {main_df.shape[0]} rows")
if history_data_pandas is not None: print(f"  - Sales history: {history_data_pandas.shape[0]} rows")
if embedding_features_for_clustering:
    print(f"  - Using embedding features: {', '.join(embedding_features_for_clustering)}")

# COMMAND ----------

# MAGIC %md
# MAGIC ### 3. Helper Functions & Feature Engineering
# MAGIC This section contains the core logic from `feature_engineering.py`.

# COMMAND ----------

# DBTITLE 1,Core Helper Functions

def find_optimal_k(X, max_k, min_group_size):
    if len(X) < min_group_size: return 1, {}
    k_range = range(2, min(max_k + 1, len(X)))
    if not k_range: return 1, {}
    if X.ndim == 1:
        X = X.reshape(-1, 1)
    scores = {}
    for k in k_range:
        kmeans = KMeans(n_clusters=k, random_state=42, n_init='auto')
        labels = kmeans.fit_predict(X)
        if len(np.unique(labels)) > 1:
            scores[k] = silhouette_score(X, labels)
    if not scores: return 1, {}
    return max(scores, key=scores.get), scores

def engineer_multi_label_feature(df: pd.DataFrame, column_name: str, all_selector_map: dict = None, prefix: str = None) -> tuple[pd.DataFrame, list]:
    if column_name not in df.columns: return df, []
    df_out = df.copy()
    all_selector = all_selector_map.get(column_name) if all_selector_map else None
    def parse_comma_separated_string(x):
        if not isinstance(x, str): return []
        return [item.strip() for item in x.split(',')]
    parsed_series = df_out[column_name].apply(parse_comma_separated_string)
    all_labels = set(l for label_list in parsed_series for l in label_list)
    if all_selector and all_selector in all_labels:
        all_labels.remove(all_selector)
    if not all_labels:
        if not all_selector: return df_out, []
    new_feature_names = []
    feature_prefix = prefix if prefix else column_name
    for label in sorted(list(all_labels)):
        if not label: continue
        new_col_name = f"{feature_prefix}_{label}"
        new_feature_names.append(new_col_name)
        df_out[new_col_name] = parsed_series.apply(lambda x: 1 if label in x or (all_selector and all_selector in x) else 0)
    return df_out, new_feature_names

def prepare_sales_history_data(sales_df: pd.DataFrame):
    if sales_df is None: return None
    print("Preparing sales history data...")
    sales_df['baselineDate'] = pd.to_datetime(sales_df['baselineDate'])
    sales_pivot = sales_df.pivot_table(index='baselineDate', columns='sku', values='saleQuantity', fill_value=0)
    stock_pivot = sales_df.pivot_table(index='baselineDate', columns='sku', values='stockQuantity', fill_value=0)
    all_dates = pd.date_range(sales_pivot.index.min(), sales_pivot.index.max())
    sales_pivot = sales_pivot.reindex(all_dates, fill_value=0)
    stock_pivot = stock_pivot.reindex(all_dates, fill_value=0)
    print("Sales history data prepared successfully.")
    return {'sales': sales_pivot, 'stock': stock_pivot}

def calculate_behavioral_distance_matrix(group_df, history_data, min_common_days):
    num_items = len(group_df)
    dist_matrix = np.ones((num_items, num_items))
    item_codes = group_df['sku'].tolist()
    for i in range(num_items):
        for j in range(i, num_items):
            if i == j:
                dist_matrix[i, j] = 0
                continue
            item1_code, item2_code = item_codes[i], item_codes[j]
            if item1_code not in history_data['sales'].columns or item2_code not in history_data['sales'].columns: continue
            sales1, stock1 = history_data['sales'][item1_code], history_data['stock'][item1_code]
            sales2, stock2 = history_data['sales'][item2_code], history_data['stock'][item2_code]
            valid_days_mask = (stock1 > 0) & (stock2 > 0)
            if valid_days_mask.sum() < min_common_days: continue
            filtered_sales1, filtered_sales2 = sales1[valid_days_mask], sales2[valid_days_mask]
            correlation = filtered_sales1.corr(filtered_sales2)
            if pd.isna(correlation): correlation = 0
            distance = 1 - abs(correlation)
            dist_matrix[i, j] = distance
            dist_matrix[j, i] = distance
    return dist_matrix

def calculate_embedding_distance_from_column(group_df: pd.DataFrame, embedding_column: str) -> np.ndarray:
    """Calculates a pairwise cosine distance matrix from a column containing string-represented embedding vectors."""
    num_items = len(group_df)
    default_dist_matrix = np.ones((num_items, num_items)) - np.identity(num_items)

    if embedding_column not in group_df.columns:
        print(f"Warning: Embedding column '{embedding_column}' not found in group. Returning default distance matrix.")
        return default_dist_matrix

    embedding_series = group_df[embedding_column]

    # Find the dimension of the embeddings from the first valid entry
    first_valid_embedding = embedding_series.dropna().iloc[0] if not embedding_series.dropna().empty else None
    if first_valid_embedding is None:
        print(f"Warning: No valid embeddings found in column '{embedding_column}'. Returning default distance matrix.")
        return default_dist_matrix
    
    try:
        # It's safer to parse it to get the object, then get length
        parsed_embedding = ast.literal_eval(first_valid_embedding)
        dim = len(parsed_embedding)
        zero_vector_str = str([0.0] * dim)
    except (ValueError, SyntaxError, TypeError):
        print(f"Warning: Could not determine embedding dimension from first entry in '{embedding_column}'. Returning default distance matrix.")
        return default_dist_matrix

    # Parse embeddings, filling NaNs with a zero vector
    embedding_strings = embedding_series.fillna(zero_vector_str).values
    
    try:
        embedding_vectors = [ast.literal_eval(s) for s in embedding_strings]
        embedding_matrix = np.array(embedding_vectors)
    except (ValueError, SyntaxError) as e:
        print(f"Error parsing embedding strings in column '{embedding_column}': {e}. Returning default distance matrix.")
        return default_dist_matrix
    
    if embedding_matrix.shape[0] != num_items:
        print(f"Warning: Shape mismatch after processing embeddings for '{embedding_column}'. Returning default distance matrix.")
        return default_dist_matrix

    dist_matrix = pairwise_distances(embedding_matrix, metric='cosine')
    dist_matrix[np.isnan(dist_matrix)] = 1.0
    dist_matrix[dist_matrix < 1e-7] = 0.0
    
    return dist_matrix

def calculate_static_distance_matrix_pca(X_pca):
    if X_pca.shape[0] == 0: return np.array([])
    if X_pca.ndim == 1:
        X_pca = X_pca.reshape(-1, 1)
    return pairwise_distances(X_pca, metric='euclidean')

# COMMAND ----------

# MAGIC %md
# MAGIC ### 4. Clustering Pipeline

# COMMAND ----------

# DBTITLE 1,Main Clustering Logic
def run_clustering(df, history_data, config, use_behavioral, embedding_features_for_clustering):
    print("\nStarting clustering process...")

    # --- Feature Engineering ---
    embedding_features = config.get('EMBEDDING_FEATURES', [])
    active_numerical_features = [f for f in config.get('NUMERICAL_FEATURES', []) if f not in embedding_features]
    active_categorical_features = [f for f in config.get('CATEGORICAL_FEATURES', []) if f not in embedding_features]
    active_weights = config.get('FEATURE_WEIGHTS', {}).copy()


    if config.get('MULTI_LABEL_FEATURES'):
        print("\nStep 1.6: Engineering multi-label features...")
        for feature in config['MULTI_LABEL_FEATURES']:
            if feature in df.columns:
                df, new_features = engineer_multi_label_feature(df, feature, all_selector_map=config.get('MULTI_LABEL_ALL_SELECTOR'))
                if new_features:
                    print(f"  - Created {len(new_features)} new features from '{feature}'.")
                    active_numerical_features.extend(new_features)
                    if feature in active_categorical_features: active_categorical_features.remove(feature)
                    if feature in active_weights:
                        weight = active_weights.pop(feature)
                        for new_feat in new_features: active_weights[new_feat] = weight
        print("Multi-label feature engineering complete.")

    # --- Preprocessor Definition ---
    preprocessor = ColumnTransformer(
        transformers=[
            ('num', StandardScaler(), active_numerical_features),
            ('cat', OneHotEncoder(handle_unknown='ignore'), active_categorical_features)
        ], remainder='drop')

    # --- Grouping and Clustering ---
    print("\nStep 2: Grouping by features and running hybrid clustering...")
    all_results = []
    cluster_logs = []
    grouping_features = config.get('GROUPING_FEATURES', [])
    if grouping_features:
        print(f"Grouping data by: {', '.join(grouping_features)}")
        grouped = df.groupby(grouping_features)
    else:
        print("No grouping features specified. Processing all data as a single group.")
        grouped = [('all_data', df)]

    for group_key, group_df_orig in grouped:
        group_df = group_df_orig.copy()
        if isinstance(group_key, tuple):
            group_name_str = '_'.join(map(str, group_key)).replace('/', '_')
        else:
            group_name_str = str(group_key).replace('/', '_')
        print(f"\n--- Processing Group: {group_name_str} ({len(group_df)} products) ---")
        original_index = group_df.index
        group_df.reset_index(drop=True, inplace=True)

        if len(group_df) == 2:
            p1 = group_df.iloc[0]
            p2 = group_df.iloc[1]
            manufacturer_col = config.get('MANUFACTURER_COLUMN', 'nha-san-xuat')
            price_col = config.get('PRICE_COLUMN', 'sellingPrice')

            if (manufacturer_col in p1 and manufacturer_col in p2 and p1[manufacturer_col] == p2[manufacturer_col]):
                # Convert prices to numeric, handling non-numeric values
                try:
                    price1 = pd.to_numeric(p1[price_col], errors='coerce')
                    price2 = pd.to_numeric(p2[price_col], errors='coerce')
                    
                    # Check if both prices are valid numbers
                    if pd.notna(price1) and pd.notna(price2):
                        small_price = min(price1, price2)
                        big_price = max(price1, price2)
                        
                        if small_price > 0 and (big_price / small_price) <= 1.5:
                            print("Pair is similar. Merging them and skipping clustering.")
                            group_results = group_df.copy()
                            group_results['sub_cluster_label'] = 0
                            group_results['group_name'] = group_name_str
                            group_results['cluster_group_name'] = f"{group_name_str}_0_manual_pair_merge"
                            group_results['cluster_method'] = 'manual_pair_merged'
                            group_results['is_outlier'] = False
                            group_results.index = original_index
                            all_results.append(group_results)
                            continue
                except (TypeError, ValueError):
                    # If conversion fails, we skip the price comparison
                    pass

        if len(group_df) < config.get('MIN_GROUP_SIZE_FOR_CLUSTERING', 3):
            group_results = group_df.copy()
            group_results['sub_cluster_label'] = -1
            group_results['group_name'] = group_name_str
            group_results['cluster_group_name'] = [f"{group_name_str}_{i}_small_group_outlier" for i in range(len(group_df))]
            group_results['cluster_method'] = 'skipped_small_group'
            group_results['is_outlier'] = True
            group_results.index = original_index
            all_results.append(group_results)
            continue

        X_processed = preprocessor.fit_transform(group_df)
        weights = []
        for name, transformer, features in preprocessor.transformers_:
            if name == 'num':
                weights.extend([active_weights.get(f, 1.0) for f in features])
            elif name == 'cat':
                for i, feature in enumerate(features):
                    num_cat = len(transformer.categories_[i])
                    weights.extend([active_weights.get(feature, 1.0)] * num_cat)
        X_weighted = X_processed * np.array(weights)
        
        # Ensure X_weighted is 2D
        if X_weighted.ndim == 1:
            X_weighted = X_weighted.reshape(-1, 1)
        
        # Handle case where we have only one feature (PCA will fail)
        if X_weighted.shape[1] <= 1:
            print("Skipping PCA due to single feature. Using weighted features directly.")
            X_for_distance = X_weighted
        else:
            pca = PCA(n_components=config.get('PCA_EXPLAINED_VARIANCE', 0.95), random_state=42)
            X_pca = pca.fit_transform(X_weighted)
            if X_pca.shape[1] < 2 and X_weighted.shape[1] >= 2:
                pca = PCA(n_components=2, random_state=42)
                X_pca = pca.fit_transform(X_weighted)
            print(f"PCA applied. New dimensions = {X_pca.shape[1]}")
            X_for_distance = X_pca
            
        # --- Distance Matrix Aggregation ---
        static_weight = active_weights.get('static_features', 1.0)
        d_final = static_weight * calculate_static_distance_matrix_pca(X_for_distance)

        if use_behavioral and history_data:
            print("Calculating behavioral distance matrix...")
            d_behavioral = calculate_behavioral_distance_matrix(group_df, history_data, config['MIN_COMMON_DAYS_FOR_CORRELATION'])
            behavioral_weight = active_weights.get('behavioral_features', 1.0)
            d_final += behavioral_weight * d_behavioral
        
        if embedding_features_for_clustering:
            print("Calculating embedding distance matrices...")
            for emb_col_name in embedding_features_for_clustering:
                if emb_col_name in group_df.columns:
                    print(f"  - Processing embedding: {emb_col_name}")
                    d_embedding = calculate_embedding_distance_from_column(group_df, emb_col_name)
                    # Weight key should be the prefixed name, e.g., 'embedding_color'
                    emb_weight = active_weights.get(emb_col_name, 1.0)
                    d_final += emb_weight * d_embedding
                else:
                    print(f"  - Warning: Embedding feature '{emb_col_name}' not found.")

        hdbscan_params = config['HDBSCAN_PARAMS'].copy()
        hdbscan_params['metric'] = 'precomputed'
        clusterer = hdbscan.HDBSCAN(**hdbscan_params)
        hdbscan_labels = clusterer.fit_predict(d_final)

        final_labels = hdbscan_labels.copy()
        cluster_methods = np.full(len(group_df), 'hdbscan', dtype=object)
        kmeans_clusters_found = 0
        num_hdbscan_clusters = len(set(hdbscan_labels)) - (1 if -1 in hdbscan_labels else 0)
        num_initial_outliers = np.sum(hdbscan_labels == -1)
        print(f"HDBSCAN found {num_hdbscan_clusters} clusters and {num_initial_outliers} initial outliers.")

        outlier_indices = np.where(hdbscan_labels == -1)[0]
        if len(outlier_indices) >= config.get('MIN_GROUP_SIZE_FOR_CLUSTERING', 3):
            print(f"Found {len(outlier_indices)} outliers. Applying K-Means...")
            outlier_data = X_for_distance[outlier_indices]
            optimal_k, _ = find_optimal_k(outlier_data, config.get('MAX_K_FOR_OUTLIERS', 10), config.get('MIN_GROUP_SIZE_FOR_CLUSTERING', 3))
            
            new_k = optimal_k + 1
            if new_k < len(outlier_data) and new_k <= config.get('MAX_K_FOR_OUTLIERS', 10):
                print(f"Original optimal k was {optimal_k}. Incrementing to {new_k} for better outlier grouping.")
                optimal_k = new_k
            else:
                print(f"Optimal k for outliers: {optimal_k}")

            if optimal_k > 1:
                kmeans = KMeans(n_clusters=optimal_k, random_state=42, n_init='auto')
                kmeans_labels = kmeans.fit_predict(outlier_data)
                max_hdbscan_label = -1 if num_hdbscan_clusters == 0 else hdbscan_labels.max()
                shifted_kmeans_labels = kmeans_labels + max_hdbscan_label + 1
                final_labels[outlier_indices] = shifted_kmeans_labels
                cluster_methods[outlier_indices] = 'kmeans'
                kmeans_clusters_found = len(set(kmeans_labels))
                print(f"K-Means clustered outliers into {kmeans_clusters_found} new groups.")
            else:
                print("K-Means did not find more than 1 cluster. Points remain as outliers.")
                cluster_methods[outlier_indices] = 'hdbscan_outlier'
        else:
            if len(outlier_indices) > 0:
                print("Not enough outliers to run K-Means.")
                cluster_methods[outlier_indices] = 'hdbscan_outlier'

        group_results = group_df.copy()
        group_results['sub_cluster_label'] = final_labels
        group_results['group_name'] = group_name_str
        group_results['cluster_method'] = cluster_methods

        price_col = config.get('PRICE_COLUMN', 'sellingPrice')
        if price_col in group_results.columns:
            all_cluster_labels = group_results['sub_cluster_label'].unique()
            for label in all_cluster_labels:
                if label == -1: continue
                cluster_mask = (group_results['sub_cluster_label'] == label)
                if cluster_mask.sum() == 2:
                    # Convert prices to numeric, handling non-numeric values
                    cluster_prices = pd.to_numeric(group_results.loc[cluster_mask, price_col], errors='coerce')
                    # Remove any NaN values
                    cluster_prices = cluster_prices.dropna()
                    
                    # Only proceed if we have valid prices
                    if len(cluster_prices) == 2:
                        small_price, big_price = cluster_prices.min(), cluster_prices.max()
                        if (small_price > 0 and (big_price / small_price) > 1.5) or small_price == 0:
                            print(f"Splitting pair cluster {label} due to high price ratio.")
                            group_results.loc[cluster_mask, 'sub_cluster_label'] = -1
                            group_results.loc[cluster_mask, 'cluster_method'] = f'price_split_from_{label}'
        
        group_results['cluster_group_name'] = ''
        clustered_mask = (group_results['sub_cluster_label'] != -1)
        if clustered_mask.any():
            base_name = group_results.loc[clustered_mask, 'group_name'] + '_' + group_results.loc[clustered_mask, 'sub_cluster_label'].astype(str).str.zfill(5)
            is_kmeans = group_results.loc[clustered_mask, 'cluster_method'] == 'kmeans'
            group_results.loc[clustered_mask, 'cluster_group_name'] = np.where(is_kmeans, base_name + '_kmeans', base_name + '_hdbscan')

        if price_col in group_results.columns:
            zero_price_mask = (group_results[price_col] == 0) & (group_results['sub_cluster_label'] != -1)
            if zero_price_mask.any():
                print(f"Found {zero_price_mask.sum()} clustered items with zero price. Adjusting their group name.")
                group_results.loc[zero_price_mask, 'cluster_group_name'] = group_results.loc[zero_price_mask, 'cluster_group_name'] + '_zero_price'

        price_split_mask = group_results['cluster_method'].str.startswith('price_split_from_')
        if price_split_mask.any():
            original_labels = group_results.loc[price_split_mask, 'cluster_method'].str.split('_').str[-1]
            split_indices = group_results[price_split_mask].groupby(original_labels).cumcount()
            base_name = group_results.loc[price_split_mask, 'group_name']
            group_results.loc[price_split_mask, 'cluster_group_name'] = base_name + '_' + original_labels + '_' + split_indices.astype(str) + '_price_split_outlier'

        other_outlier_mask = (group_results['sub_cluster_label'] == -1) & (~price_split_mask)
        if other_outlier_mask.any():
            num_other_outliers = other_outlier_mask.sum()
            outlier_base_name = group_results.loc[other_outlier_mask, 'group_name'].iloc[0]
            outlier_names = [f"{outlier_base_name}_{i}_hdbscan_outlier" for i in range(num_other_outliers)]
            group_results.loc[other_outlier_mask, 'cluster_group_name'] = outlier_names

        group_results['is_outlier'] = (group_results['sub_cluster_label'] == -1)
        group_results.index = original_index
        all_results.append(group_results)

        num_final_clusters = len(set(final_labels)) - (1 if -1 in final_labels else 0)
        num_final_outliers = np.sum(final_labels == -1)
        cluster_logs.append({
            'group_key': group_name_str,
            'num_products': len(group_df),
            'pca_components': X_for_distance.shape[1],
            'hdbscan_clusters': num_hdbscan_clusters,
            'initial_outliers': num_initial_outliers,
            'kmeans_clusters_on_outliers': kmeans_clusters_found,
            'final_clusters': num_final_clusters,
            'final_outliers': num_final_outliers
        })

    if not all_results:
        return df.iloc[0:0], pd.DataFrame([{'status': 'no_results'}])

    final_df = pd.concat(all_results)
    log_df = pd.DataFrame(cluster_logs)
    return final_df, log_df

# Run the pipeline
history_prepared = prepare_sales_history_data(history_data_pandas)
final_results_df, log_summary_df = run_clustering(main_df, history_prepared, CONFIG, use_behavioral, embedding_features_for_clustering)

# Add group_id for partitioning and identification
if not log_summary_df.empty:
    log_summary_df['group_id'] = group_id

# COMMAND ----------

# MAGIC %md
# MAGIC ### 5. Save Results

# COMMAND ----------

final_results_spark_df = spark.createDataFrame(final_results_df).printSchema()

# COMMAND ----------

# DBTITLE 1,Write Results to Delta Tables
final_results_spark_df = spark.createDataFrame(final_results_df).select("sku", "group_id", "cluster_method", "cluster_group_name")
log_summary_spark_df = spark.createDataFrame(log_summary_df)

output_table_name = f"{catalog}.{database}.standard_sku_clustering_results"
log_table_name = f"{catalog}.{database}.standard_sku_clustering_logs"

print(f"\nWriting results to:")
print(f"  - Clusters: {output_table_name}")
print(f"  - Logs: {log_table_name}")

# This logic handles table creation on first run and atomic updates for subsequent runs.
# It ensures that each run for a group_id overwrites only its own data in the common table.

def upsert_to_delta(spark_df, table_name, group_id):
    if spark.catalog.tableExists(table_name):
        # If table exists, use replaceWhere to overwrite data for the specific group_id
        spark_df.write.format("delta").mode("overwrite").option("replaceWhere", f"group_id = '{group_id}'").save(table_name)
    else:
        # If table doesn't exist, create it and partition by group_id
        # This will only contain data for the first group_id that is run
        spark_df.write.format("delta").partitionBy("group_id").saveAsTable(table_name)

upsert_to_delta(final_results_spark_df, output_table_name, group_id)
upsert_to_delta(log_summary_spark_df, log_table_name, group_id)

print("\nPipeline finished successfully!")

# COMMAND ----------

# DBTITLE 1,Display Final Results
display(spark.table(output_table_name))
