# This script reads CSV files from a Unity Catalog Volume and creates Delta tables.
# It is designed to be run as a standard Python script within a Databricks environment
# (e.g., as a job or executed from a notebook).

import sys
from pyspark.sql import SparkSession
from pyspark.sql.functions import col
from pyspark.sql.types import (
    DoubleType, StringType, IntegerType, LongType,
    ShortType, FloatType, DecimalType
)
from shared_udf import setup_catalog

# --- Configuration ---
# The catalog and database where the new tables will be created.
CATALOG_NAME = setup_catalog()
DATABASE_NAME = "mrp_dw"

# The UC Volume path where your CSV files are located.
DBFS_PATH = f"/Volumes/{CATALOG_NAME}/{mrp_dw}/mrp_volume/standard_sku/input_data/"

# List of CSV files and their corresponding target table names.
CSV_FILES_TO_TABLES = {
    "dmp_chong_nang_final_Sheet1.csv": "standard_sku_dmp_chong_nang_features",
    "khang_sinh.csv": "standard_sku_khang_sinh_features",
    "sales_stock_90_days_khang_sinh.csv": "standard_sku_khang_sinh_sales_stock_90_days",
    "dmp_chong_nang_item_embeddings.csv": "standard_sku_dmp_chong_nang_embeddings",
}

def create_table_from_csv(spark: SparkSession, dbfs_file_path: str, table_name: str):
    """
    Reads a CSV from a UC Volume, casts numeric columns to DoubleType
    (while preserving ID columns as strings), and saves it as a Delta table.
    """
    print(f"Processing {dbfs_file_path}...")

    try:
        # Read the CSV with header and inferred schema using the full dataset
        df = spark.read.format("csv") \
            .option("header", "true") \
            .option("inferSchema", "true") \
            .option("samplingRatio", "1.0") \
            .load(dbfs_file_path)

        print("Schema inferred by Spark:")
        df.printSchema()

        # Define numeric types to be cast to Double
        numeric_types = (IntegerType, LongType, ShortType, FloatType, DecimalType, DoubleType)
        # Define suffixes for ID columns that should remain strings
        id_suffixes = ("code", "id")

        select_exprs = []
        for field in df.schema.fields:
            col_name = f"`{field.name}`"
            lower_col_name = field.name.lower()

            # Check if the column is an ID column
            if lower_col_name.endswith(id_suffixes):
                if not isinstance(field.dataType, StringType):
                    print(f"  - Casting ID column '{field.name}' to StringType.")
                    select_exprs.append(col(col_name).cast(StringType()).alias(field.name))
                else:
                    select_exprs.append(col(col_name))
            # Check if the inferred type is numeric (and not an ID column)
            elif isinstance(field.dataType, numeric_types):
                print(f"  - Casting column '{field.name}' from {field.dataType} to DoubleType.")
                select_exprs.append(col(col_name).cast(DoubleType()).alias(field.name))
            else:
                # Keep original type for other non-numeric columns
                select_exprs.append(col(col_name))

        df_casted = df.select(*select_exprs)

        print(f"\nFinal Schema for {table_name}:")
        df_casted.printSchema()

        print(f"\nWriting data to Delta table: {table_name}")
        df_casted.write.format("delta") \
          .mode("overwrite") \
          .option("overwriteSchema", "true") \
          .saveAsTable(table_name)

        print(f"Successfully created table: {table_name}\n")

    except Exception as e:
        print(f"Error processing {dbfs_file_path}: {e}\n", file=sys.stderr)

def main(spark: SparkSession):
    """Main execution logic."""
    print("Starting script to create tables from CSVs...")

    # Ensure the target database exists
    spark.sql(f"CREATE DATABASE IF NOT EXISTS {CATALOG_NAME}.{DATABASE_NAME}")

    for csv_file, table_suffix in CSV_FILES_TO_TABLES.items():
        full_dbfs_path = f"{DBFS_PATH}{csv_file}"
        full_table_name = f"{CATALOG_NAME}.{DATABASE_NAME}.{table_suffix}"

        create_table_from_csv(spark, full_dbfs_path, full_table_name)

    print("--- All files processed. ---")

if __name__ == "__main__":
    # This block allows the script to be run directly,
    # for example, as a Databricks job.
    spark_session = SparkSession.builder.appName("CsvToDeltaRobust").getOrCreate()
    main(spark_session)
