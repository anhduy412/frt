-- This script creates the configuration table for the clustering pipeline.
-- It is designed to be run in a Databricks SQL environment or a notebook.

CREATE TABLE IF NOT EXISTS `${catalog_name}`.`${database_name}`.clustering_configs (
    config_set STRING NOT NULL COMMENT 'A unique name for a set of configurations, e.g., "chong_nang".',
    param_key STRING NOT NULL COMMENT 'The name of the configuration parameter, e.g., "PCA_EXPLAINED_VARIANCE".',
    param_value STRING COMMENT 'The value of the parameter, stored as a string. Complex types like lists or dicts should be stored as JSON strings.',
    param_type STRING NOT NULL COMMENT 'The data type of the value (e.g., "float", "int", "string", "json", "boolean") to aid in parsing.',
    last_updated_at TIMESTAMP COMMENT 'Timestamp of the last update.'
)
USING DELTA
COMMENT 'A centralized table to store configurations for the product clustering pipeline.'
TBLPROPERTIES ('delta.autoOptimize.optimizeWrite' = 'true', 'delta.autoOptimize.autoCompact' = 'true');