# Databricks notebook source
# DBTITLE 1, Widget and Parameter Setup
dbutils.widgets.text("group_id", "than_kinh_nao", "Group ID to process")
GROUP_ID = dbutils.widgets.get("group_id")

# COMMAND ----------

# DBTITLE 1, Imports and Header
import pyspark.sql.functions as F
from pyspark.sql.types import StringType, StructType, StructField, MapType, Iterator, ArrayType, FloatType, IntegerType
from pyspark.sql import SparkSession
import pandas as pd
from google import genai
import os
import json
import time
from shared_udf import setup_catalog

# COMMAND ----------

# DBTITLE 1, Spark, Catalog, and API Key Configuration
spark = SparkSession.builder.getOrCreate()

# Initialize Catalog
CATALOG_NAME = setup_catalog()
DATABASE = 'tft_serving'

# Securely retrieve the Gemini API Key from Databricks Secrets
env = os.getenv('MY_ENV', '').lower()
env_kv = '' if env == '' else env + '-'

SCOPE = f'{env_kv}dataplatform-vault-scope'

GEMINI_API_KEY = dbutils.secrets.get(scope=SCOPE, key="frt-gemini-api-key")

print(f"Successfully configured for Catalog: '{CATALOG_NAME}' and Group ID: {GROUP_ID}")

# COMMAND ----------

# DBTITLE 1, Data Ingestion
TABLE_NAME = f"{CATALOG_NAME}.{DATABASE}.standard_sku_features_value"
print(f"Reading data from {TABLE_NAME}")

source_df = spark.table(TABLE_NAME)

# Filter for the selected group_id if not 'all'
if GROUP_ID.lower() != 'all':
    source_df = source_df.filter(F.col("group_id") == GROUP_ID)

# A value is invalid if it's NULL, 'not_available', blank, or whitespace only.
no_valid_source_condition = (
    F.col("value_embedding").isNull() &
    ~((F.col("value_norm").isNotNull() & (F.trim(F.col("value_norm")) != "") & (F.col("value_norm") != "not_available")) |
      (F.col("value_original").isNotNull() & (F.trim(F.col("value_original")) != "") & (F.col("value_original") != "not_available")) |
      (F.col("value_ai").isNotNull() & (F.trim(F.col("value_ai")) != "") & (F.col("value_ai") != "not_available")))
)

# Identify rows that have no valid source values and need to be marked with "not_available"
no_valid_source_df = source_df.filter(no_valid_source_condition).select("sku", "attribute_id", "group_id")

# COMMAND ----------

# DBTITLE 1, Update Rows with No Valid Data Source
# Merge "not_available" for rows with no valid source data
no_valid_source_df_count = no_valid_source_df.count()

if no_valid_source_df_count > 0:
    print(f"Found {no_valid_source_df_count} rows with no valid data source to update.")
    no_valid_source_df.createOrReplaceTempView("no_valid_source_updates_temp")

    merge_sql_no_source = f"""
        MERGE INTO {TABLE_NAME} AS target
        USING no_valid_source_updates_temp AS source
        ON target.sku = source.sku AND target.attribute_id = source.attribute_id AND target.group_id = source.group_id
        WHEN MATCHED AND target.value_embedding IS NULL THEN
          UPDATE SET target.value_embedding = 'not_available'
    """
    spark.sql(merge_sql_no_source)
    print("Updated rows with no valid data source to 'not_available'.")

# COMMAND ----------

# DBTITLE 1, Filter for Rows That Need Embedding Calculation
# Now, filter for rows that still need embedding (have valid source data)
needs_embedding_df = source_df.filter(
    F.col("value_embedding").isNull() &
    (
        (F.col("value_norm").isNotNull() & (F.trim(F.col("value_norm")) != "") & (F.col("value_norm") != "not_available")) |
        (F.col("value_original").isNotNull() & (F.trim(F.col("value_original")) != "") & (F.col("value_original") != "not_available")) |
        (F.col("value_ai").isNotNull() & (F.trim(F.col("value_ai")) != "") & (F.col("value_ai") != "not_available"))
    )
)

# Select only necessary columns to pass to the UDF
needs_embedding_df = needs_embedding_df.select("sku", "attribute_id", "group_id", "value_norm", "value_original", "value_ai")

# Cache the dataframe to process
needs_embedding_df.cache()
total_rows = needs_embedding_df.count()
print(f"Found {total_rows} rows that need embedding calculation.")


# COMMAND ----------

# DBTITLE 1, Process Embeddings with Dynamic Batching and Merging
if total_rows > 0:
    print(f"Collecting {total_rows} rows to calculate embeddings...")
    rows_to_process = needs_embedding_df.select("sku", "attribute_id", "group_id", "value_norm", "value_original", "value_ai").collect()

    def get_text_to_embed(row):
        val_norm = row['value_norm']
        if val_norm is not None and str(val_norm).strip() not in ["", "not_available"]:
            return str(val_norm)
        val_orig = row['value_original']
        if val_orig is not None and str(val_orig).strip() not in ["", "not_available"]:
            return str(val_orig)
        val_ai = row['value_ai']
        if val_ai is not None and str(val_ai).strip() not in ["", "not_available"]:
            return str(val_ai)
        return None

    embedding_schema = StructType([
        StructField("sku", StringType(), False),
        StructField("attribute_id", IntegerType(), False),
        StructField("group_id", StringType(), False),
        StructField("value_embedding", StringType(), False)
    ])

    def merge_embeddings(embeddings_to_merge):
        if not embeddings_to_merge:
            return 0

        print(f"Merging {len(embeddings_to_merge)} embeddings...")
        try:
            embeddings_df = spark.createDataFrame(embeddings_to_merge, schema=embedding_schema)
            embeddings_df.createOrReplaceTempView("embedding_updates_temp")

            merge_sql = f"""
                MERGE INTO {TABLE_NAME} AS target
                USING embedding_updates_temp AS source
                ON target.sku = source.sku AND target.attribute_id = source.attribute_id AND target.group_id = source.group_id
                WHEN MATCHED AND target.value_embedding IS NULL THEN
                  UPDATE SET target.value_embedding = source.value_embedding
            """
            spark.sql(merge_sql)

            count = embeddings_df.count()
            print(f"Successfully merged {count} embeddings.")
            return count
        except Exception as e:
            print(f"An error occurred during merge: {e}")
            return 0

    client = genai.Client(api_key=GEMINI_API_KEY)
    model = "gemini-embedding-001"

    embeddings_to_merge = []
    total_merged_count = 0
    API_PAYLOAD_LIMIT_BYTES = 4 * 1024 * 1024  # 4MB

    current_index = 0
    while current_index < len(rows_to_process):
        batch_sizes_to_try = [100, 80, 60, 40, 20, 1]

        # Prepare the full potential batch of texts and keys for size calculation
        valid_rows_in_batch = []
        for i in range(current_index, len(rows_to_process)):
            row = rows_to_process[i]
            text = get_text_to_embed(row)
            if text:
                valid_rows_in_batch.append({'text': text, 'row': row})

        final_batch_size = 0
        texts_for_api = []
        keys_for_api = []

        for size in batch_sizes_to_try:
            if size > len(valid_rows_in_batch):
                continue

            potential_texts = [item['text'] for item in valid_rows_in_batch[:size]]
            payload_size = sum(len(t.encode('utf-8')) for t in potential_texts)

            if payload_size < API_PAYLOAD_LIMIT_BYTES:
                texts_for_api = potential_texts
                keys_for_api = [item['row'] for item in valid_rows_in_batch[:size]]
                final_batch_size = len(keys_for_api)
                break

        if not texts_for_api: # Handle single item > 4MB
            item = valid_rows_in_batch[0]
            text_bytes = item['text'].encode('utf-8')
            truncated_text = text_bytes[:API_PAYLOAD_LIMIT_BYTES].decode('utf-8', 'ignore')
            texts_for_api = [truncated_text]
            keys_for_api = [item['row']]
            final_batch_size = 1
            print(f"Warning: A single text item was larger than 4MB and has been truncated. SKU: {keys_for_api[0]['sku']}")

        print(f"Processing batch of {len(texts_for_api)} items (Index: {current_index})...")
        try:
            result = client.models.embed_content(model=model, contents=texts_for_api)

            if hasattr(result, 'embeddings') and len(result.embeddings) == len(keys_for_api):
                for i, row_data in enumerate(keys_for_api):
                    embedding_json = json.dumps(result.embeddings[i].values)
                    embeddings_to_merge.append({
                        "sku": row_data['sku'], "attribute_id": row_data['attribute_id'], "group_id": row_data['group_id'],
                        "value_embedding": embedding_json
                    })
            else:
                print(f"Warning: Mismatch in embedding results for batch starting at index {current_index}.")

        except Exception as e:
            print(f"An error occurred during embedding for batch starting at index {current_index}: {e}")

        current_index += final_batch_size

        if len(embeddings_to_merge) >= 500:
            num_merged = merge_embeddings(embeddings_to_merge)
            total_merged_count += num_merged
            embeddings_to_merge = []

    if embeddings_to_merge:
        num_merged = merge_embeddings(embeddings_to_merge)
        total_merged_count += num_merged

    print(f"\nTotal successfully merged embeddings: {total_merged_count}")
    needs_embedding_df.unpersist()
else:
    print("No rows to process.")

# COMMAND ----------

# DBTITLE 1, Final Summary and Optimize
print("\n------------------------------------")
print("Embedding process complete.")
if total_rows > 0:
    print(f"Total rows processed: {total_rows}")
    print("\n------------------------------------")
    print(f"Optimizing the target table: {TABLE_NAME}")
    spark.sql(f"OPTIMIZE {TABLE_NAME}")
    print("Optimization complete.")
