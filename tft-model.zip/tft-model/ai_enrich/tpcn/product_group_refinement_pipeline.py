# Databricks notebook source
# DBTITLE 1, Widget and Parameter Setup
dbutils.widgets.text("batch_size", "10", "Batch size for processing")
BATCH_SIZE = int(dbutils.widgets.get("batch_size"))

# COMMAND ----------

# DBTITLE 1, Imports and Header
import pyspark.sql.functions as F
from pyspark.sql.types import StringType, StructType, StructField
from pyspark.sql import SparkSession
import pandas as pd
from google import genai
from google.genai import types
import os
import json
import time
from shared_udf import setup_catalog

# COMMAND ----------

# DBTITLE 1, Spark, Catalog, and API Key Configuration
spark = SparkSession.builder.getOrCreate()

# Initialize Catalog
CATALOG_NAME = setup_catalog()
DATABASE = 'tft_serving'

# Securely retrieve the Gemini API Key from Databricks Secrets
env = os.getenv('MY_ENV', '').lower()
env_kv = '' if env == '' else env + '-'

SCOPE = f'{env_kv}dataplatform-vault-scope'

GEMINI_API_KEY = dbutils.secrets.get(scope=SCOPE, key="frt-gemini-api-key")

print(f"Successfully configured for Catalog: '{CATALOG_NAME}'")

# COMMAND ----------

# DBTITLE 1, Fetch valid product groups
print("Fetching valid product groups...")
try:
    valid_groups_df = spark.table(f"{CATALOG_NAME}.{DATABASE}.standard_sku_group")
    valid_groups = valid_groups_df.collect()
    valid_group_ids = [row['group_id'] for row in valid_groups]
    valid_group_dict = {row['group_id']: row['group_name'] for row in valid_groups}
    print(f"Found {len(valid_group_ids)} valid product groups.")
except Exception as e:
    print(f"Error fetching valid groups: {e}")
    raise

# COMMAND ----------

# DBTITLE 1, Data Preparation - Fetch SKUs that need group assignment
print("Fetching SKUs that need group assignment...")
try:
    # Get SKUs that have no group assignment
    skus_to_process_df = spark.table(f"{CATALOG_NAME}.{DATABASE}.config_product_group") \
        .filter(
            (F.col("product_group_manual_id").isNull() |
             F.col("product_group_manual_id").contains("/")
             ) &
            F.col("product_group_ai_id").isNull()) \
        .select(F.col("item_code").alias("sku"))

    print(f"Found {skus_to_process_df.count()} SKUs to process.")
except Exception as e:
    print(f"Error fetching SKUs to process: {e}")
    raise

# COMMAND ----------

# DBTITLE 1, Fetch attribute data for SKUs
print("Fetching attribute data for SKUs...")
try:
    # Get attribute values for these SKUs
    attribute_values_df = spark.table(f"{CATALOG_NAME}.{DATABASE}.standard_sku_features_value") \
        .join(skus_to_process_df.select("sku"), "sku", "inner")

    # Get attribute names
    attribute_names_df = spark.table(f"{CATALOG_NAME}.{DATABASE}.standard_sku_features") \
        .select("attribute_id", "attribute_name")

    # Join to get attribute names
    sku_attributes_df = attribute_values_df.join(attribute_names_df, "attribute_id")

    # Apply value priority: value_norm > value_original > value_ai
    sku_attributes_priority_df = sku_attributes_df.withColumn(
        "final_value",
        F.when(F.col("value_norm").isNotNull() & (F.col("value_norm") != "not_available"), F.col("value_norm"))
         .when(F.col("value_original").isNotNull() & (F.col("value_original") != "not_available"), F.col("value_original"))
         .when(F.col("value_ai").isNotNull() & (F.col("value_ai") != "not_available"), F.col("value_ai"))
         .otherwise(None)
    ).filter(F.col("final_value").isNotNull())

    # Collect data to driver for processing
    sku_attributes_rows = sku_attributes_priority_df.collect()

    # Group by SKU for easier processing
    sku_attributes_dict = {}
    for row in sku_attributes_rows:
        sku = row['sku']
        if sku not in sku_attributes_dict:
            sku_attributes_dict[sku] = {}
        sku_attributes_dict[sku][row['attribute_name']] = row['final_value']

    print(f"Prepared attribute data for {len(sku_attributes_dict)} SKUs.")
except Exception as e:
    print(f"Error fetching attribute data: {e}")
    raise

# COMMAND ----------

# DBTITLE 1, LLM-based Group Assignment
PROMPT_TEMPLATE = """
Nhiệm vụ của bạn là phân loại sản phẩm vào nhóm phù hợp nhất dựa trên các thuộc tính được cung cấp.

Các nhóm sản phẩm hợp lệ và tên của chúng:
{valid_groups}

Thông tin sản phẩm (với các giá trị thuộc tính):
{product_attributes}

Hãy phân tích kỹ các thuộc tính của sản phẩm và chọn nhóm phù hợp nhất từ danh sách các nhóm hợp lệ đã cho.
Trả về MÃ NHÓM (group_id) phù hợp nhất cho sản phẩm này.
Chỉ trả về MÃ NHÓM, không thêm bất kỳ văn bản nào khác.

Ví dụ về đầu ra hợp lệ:
G001
"""

def clean_group_response(text):
    """Extracts the group ID from the model's response text."""
    try:
        # Extract alphanumeric group ID
        import re
        match = re.search(r'[a-zA-Z0-9_]+', text.strip())
        if match:
            return match.group(0)
    except Exception:
        return None
    return None

# Configure Gemini client on the driver
client = genai.Client(api_key=GEMINI_API_KEY)
grounding_tool = types.Tool(google_search=types.GoogleSearch())
client_config = types.GenerateContentConfig(tools=[grounding_tool])

total_skus_processed = 0
total_skus_updated = 0

# Get list of SKUs to process
skus_to_process = list(sku_attributes_dict.keys())
total_skus = len(skus_to_process)

print(f"Starting group assignment for {total_skus} SKUs...")

# Process in batches
for i in range(0, total_skus, BATCH_SIZE):
    batch_skus = skus_to_process[i:i+BATCH_SIZE]
    print(f"Processing batch {i//BATCH_SIZE + 1}/{(total_skus-1)//BATCH_SIZE + 1} ({len(batch_skus)} SKUs)")

    update_rows = []

    for sku in batch_skus:
        total_skus_processed += 1
        print(f"Processing SKU {total_skus_processed}/{total_skus}: {sku}")

        # Get attributes for this SKU
        attributes = sku_attributes_dict[sku]
        if not attributes:
            print(f"  > No attributes found for SKU {sku}. Skipping.")
            continue

        # Format attributes for prompt
        attributes_str = json.dumps(attributes, ensure_ascii=False, indent=2)

        # Format valid groups for prompt
        valid_groups_str = json.dumps(valid_group_dict, ensure_ascii=False, indent=2)

        # Create prompt
        prompt = PROMPT_TEMPLATE.format(
            valid_groups=valid_groups_str,
            product_attributes=attributes_str
        )

        # Call API with retry logic
        group_id = None
        api_failures = 0
        invalid_returns = 0
        max_api_retries = 10
        max_invalid_retries = 10

        while group_id is None and api_failures < max_api_retries and invalid_returns < max_invalid_retries:
            try:
                response = client.models.generate_content(
                    model="gemini-2.5-pro",
                    contents=prompt,
                    config=client_config
                )

                # Clean and validate response

                candidate_group_id = clean_group_response(response.text)
                print(f"cleaned group id: {candidate_group_id}")

                # print(valid_group_ids)
                if candidate_group_id is not None and candidate_group_id in valid_group_ids:
                    group_id = candidate_group_id
                    print(f"  > Assigned group {group_id} to SKU {sku}")
                    # Reset both counters on success
                    api_failures = 0
                    invalid_returns = 0
                else:
                    # Invalid group returned
                    invalid_returns += 1
                    print(f"  > Invalid group returned: {candidate_group_id}. Retry {invalid_returns}/{max_invalid_retries}")
                    if invalid_returns < max_invalid_retries:
                        time.sleep(2)  # Short delay before retry
                    continue  # Continue to next retry attempt
            except Exception as e:
                # API failure
                api_failures += 1
                print(f"  > API attempt {api_failures} failed: {e}")
                if api_failures < max_api_retries:
                    time.sleep(5)  # Longer delay before retry
                continue  # Continue to next retry attempt

        if group_id:
            update_rows.append((sku, group_id))
            total_skus_updated += 1
        else:
            print(f"  > Failed to assign group to SKU {sku} after all retries.")

    # Update database with batch results
    if update_rows:
        try:
            updates_df = spark.createDataFrame(update_rows, ["sku", "product_group_ai_id"])
            updates_df.createOrReplaceTempView("group_updates_temp")

            merge_sql = f"""
                MERGE INTO {CATALOG_NAME}.{DATABASE}.config_product_group AS target
                USING group_updates_temp AS source
                ON target.item_code = source.sku
                WHEN MATCHED THEN
                  UPDATE SET target.product_group_ai_id = source.product_group_ai_id
            """
            spark.sql(merge_sql)
            print(f"  > Successfully updated {len(update_rows)} SKUs in database.")
        except Exception as e:
            print(f"  > Failed to update database with batch results: {e}")

# COMMAND ----------

# DBTITLE 1, Final Summary
print("\n------------------------------------")
print("Product group refinement process complete.")
print(f"Total SKUs processed: {total_skus_processed}")
print(f"Total SKUs updated with new groups: {total_skus_updated}")

# COMMAND ----------

# DBTITLE 1, Optimize Table
if total_skus_updated > 0:
    print("\n------------------------------------")
    print(f"Optimizing the target table: {CATALOG_NAME}.{DATABASE}.config_product_group")
    spark.sql(f"OPTIMIZE {CATALOG_NAME}.{DATABASE}.config_product_group")
    print("Optimization complete.")
