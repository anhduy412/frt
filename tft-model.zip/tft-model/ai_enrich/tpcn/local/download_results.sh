#!/usr/bin/env bash

BATCH_NAME="$1" # Your batch job name

curl https://generativelanguage.googleapis.com/v1beta/$BATCH_NAME \
-H "x-goog-api-key: $GEMINI_API_KEY" \
-H "Content-Type:application/json" 2> /dev/null > batch_status.json

if jq -r '.done' batch_status.json | grep -q "false"; then
    echo "Batch has not finished processing"
fi

batch_state=$(jq -r '.metadata.state' batch_status.json)
if [[ $batch_state = *"SUCCEEDED"* ]]; then
    if [[ $(jq '.response | has("inlinedResponses")' batch_status.json) = "true" ]]; then
        jq -r '.response.inlinedResponses' batch_status.json
        exit
    fi
    responses_file_name=$(jq -r '.response.responsesFile' batch_status.json)
    curl https://generativelanguage.googleapis.com/download/v1beta/$responses_file_name:download?alt=media \
    -H "x-goog-api-key: $GEMINI_API_KEY" > "$2" 2> /dev/null
elif [[ $batch_state = *"FAILED"* ]]; then
    jq '.error' batch_status.json
elif [[ $batch_state == *"CANCELLED"* ]]; then
    echo "Batch was cancelled by the user"
elif [[ $batch_state == *"EXPIRED"* ]]; then
    echo "Batch expired after 48 hours"
fi
