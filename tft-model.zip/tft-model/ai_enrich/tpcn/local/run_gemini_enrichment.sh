#!/bin/bash

# This script will repeatedly execute the python script "gemini_enrichment.py"
# until it completes successfully (i.e., exits with a code of 0).

while true; do
    python3 gemini_enrichment.py
    exit_code=$?
    if [ $exit_code -eq 0 ]; then
        echo "Python script executed successfully."
        break
    else
        echo "Python script failed with exit code $exit_code. Restarting in 5 seconds..."
        sleep 5
    fi
done

