import pandas as pd

# Define file paths
sales_file = 'thuc_pham_chuc_nang_with_sales.csv'
descriptions_file = 'thuc_pham_chuc_nang_descriptions.csv'
categories_file = 'thuc_pham_chuc_nang_nhom_final.csv'
output_file = 'full_description.csv'

# Load the CSV files
try:
    sales_df = pd.read_csv(sales_file)
    descriptions_df = pd.read_csv(descriptions_file)
    categories_df = pd.read_csv(categories_file)
except FileNotFoundError as e:
    print(f"Error: {e}. Please make sure all input files are in the same directory.")
    exit()

# Get the list of SKUs from the sales file
skus_to_process = sales_df[['itemCode']].copy()

# Merge with descriptions data
# Note: 'itemCode' from sales matches 'sku' in descriptions
merged_df = pd.merge(skus_to_process, descriptions_df, left_on='itemCode', right_on='sku', how='left')

# Define columns for the full description
description_cols = [
    'web_name', 'heading_text', 'description', 'ingredient', 
    'dosage', 'usage', 'careful', 'short_description', 'attributes'
]

# Create the 'full_description' column
for col in description_cols:
    if col not in merged_df.columns:
        merged_df[col] = '' # Add missing columns as empty strings
    merged_df[col] = merged_df[col].fillna('').astype(str)

merged_df['full_description'] = merged_df[description_cols].apply(lambda x: ' '.join(x), axis=1)

# Merge with categories data
final_df = pd.merge(merged_df, categories_df, on='itemCode', how='left')

# Select and rename the final columns
final_df = final_df[['itemCode', 'web_name', 'full_description', 'productGroupName']]
final_df = final_df.rename(columns={'productGroupName': 'category'})

# Save the final DataFrame to a new CSV file
final_df.to_csv(output_file, index=False)

print(f"Successfully created '{output_file}' with {len(final_df)} rows.")
