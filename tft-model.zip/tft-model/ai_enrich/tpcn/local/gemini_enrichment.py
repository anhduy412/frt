import pandas as pd
from google import genai
from google.genai import types
import os
import json
from tqdm import tqdm
import time

# --- Configuration ---
API_KEY = os.getenv("GEMINI_API_KEY")
if not API_KEY:
    raise ValueError("GEMINI_API_KEY environment variable not set. Please set it before running.")

MODEL_NAME = 'gemini-2.5-pro'
INPUT_FILE = 'full_description.csv'
OUTPUT_FILE = 'gemini_enrichment.csv'

# --- Prompt Template ---
PROMPT_TEMPLATE = """
tôi đang bán sản phẩm {web_name}, tìm giúp tôi các attributes sau:

description
ingredient
dosage (format đơn giản, chỉ khối lượng của đơn vị nhỏ nhất, chỉ 1 trong 2 đơn vị là g hoặc ml, ví dụ: 500g, 100ml)
adverse_effect
preservation
careful
short_description
diseases (loại bệnh, có thể nhiều, cách nhau bằng dấu phẩy)
cong_dung (công dụng của sản phẩm)
doi_tuong_su_dung (đối tượng sử dụng)
do_tuoi (độ tuổi sử dụng, ví dụ: người lớn/trẻ nhỏ)
lieu_luong (liều lượng):
tan_suat_su_dung (tần suất sử dụng)
dang_bao_che (dạng bào chế, vd Viên nén)

Hiện tại tôi có description không đầy đủ  như sau: {full_description}

Nhiệm vụ của bạn là:

+ kiểm tra xem nội dung và các trường thông tin trên có đủ hoặc thiếu hay không.
+ nếu chưa đầy đủ hãy tìm trên internet và lấy đầy đủ về
+ viết lại description đầy đủ để có thể bán hàng trên mạng.
+ trả lại data cho tôi dưới dạng json chứa tất cả các trường cần thiết và giá trị hợp lí.

{{
    "description" : {{
         "old_value" : "nội dung cũ..." ,
         "new_value" : "str nội dung mới nếu nội dung cũ không phù hợp..."
    }},
   "ingredient": {{ "old_value": "...", "new_value": "..."}},
   "dosage": {{ "old_value": "...", "new_value": "..."}},
   "adverse_effect": {{ "old_value": "...", "new_value": "..."}},
   "preservation": {{ "old_value": "...", "new_value": "..."}},
   "careful": {{ "old_value": "...", "new_value": "..."}},
   "short_description": {{ "old_value": "...", "new_value": "..."}},
   "diseases": {{ "old_value": "...", "new_value": "..."}},
   "cong_dung": {{ "old_value": "...", "new_value": "..."}},
   "doi_tuong_su_dung": {{ "old_value": "...", "new_value": "..."}},
   "do_tuoi": {{ "old_value": "...", "new_value": "..."}},
   "lieu_luong": {{ "old_value": "...", "new_value": "..."}},
   "tan_suat_su_dung": {{ "old_value": "...", "new_value": "..."}},
   "dang_bao_che": {{ "old_value": "...", "new_value": "..."}}
}}
"""

def clean_json_response(text):
    """Extracts the JSON object from the model's response text."""
    try:
        start = text.find('{')
        end = text.rfind('}') + 1
        if start != -1 and end != 0:
            return text[start:end]
    except Exception:
        return None
    return None

def format_sources_from_grounding(response):
    """Extracts and formats sources from the grounding metadata."""
    sources = []
    try:
        # Check if response has candidates and grounding metadata
        if (response.candidates and
            len(response.candidates) > 0 and
            response.candidates[0].grounding_metadata):

            grounding_metadata = response.candidates[0].grounding_metadata

            # Check if there are grounding chunks and supports
            if (hasattr(grounding_metadata, 'grounding_chunks') and
                grounding_metadata.grounding_chunks is not None):

                chunks = grounding_metadata.grounding_chunks

                for i, chunk in enumerate(chunks):
                    if hasattr(chunk, 'web') and hasattr(chunk.web, 'uri'):
                        uri = chunk.web.uri
                        sources.append(f"{i+1}: {uri}")

        return ", ".join(sources) if sources else ""
    except Exception as e:
        print(f"Error extracting sources: {e}")
        return ""

def enrich_and_save(df_to_process, output_df):
    """Enriches data and saves progress incrementally."""
    client = genai.Client(api_key=os.environ.get("GEMINI_API_KEY"))
    grounding_tool = types.Tool(google_search=types.GoogleSearch())
    config = types.GenerateContentConfig(tools=[grounding_tool])

    print(f"Starting data enrichment for {len(df_to_process)} products...")

    for index, row in tqdm(df_to_process.iterrows(), total=df_to_process.shape[0]):
    # for index, row in df_to_process.iterrows():
        web_name = row.get('web_name', '')
        full_description = row.get('full_description', '')

        prompt = PROMPT_TEMPLATE.format(web_name=web_name, full_description=full_description)

        # try:
        response = client.models.generate_content(
            model="gemini-2.5-pro",
            contents=prompt,
            config=config,
        )
        json_str = clean_json_response(response.text)

        if json_str:
            data = json.loads(json_str)
            # Update the output dataframe with the new values
            for key, value in data.items():
                if key in output_df.columns:
                    output_df.loc[index, key] = value.get('new_value')

            # Extract and format sources from grounding metadata
            sources = format_sources_from_grounding(response)
            output_df.loc[index, 'sources'] = sources

            output_df.loc[index, 'enriched'] = True
            # print(json_str)
        else:
            output_df.loc[index, 'enriched'] = False # Mark as failed

        # except Exception as e:
        #     print(f"An error occurred for itemCode {row['itemCode']}: {e}")
        #     output_df.loc[index, 'enriched'] = False # Mark as failed

        # Save after each API call to ensure progress is not lost
        output_df.to_csv(OUTPUT_FILE, index=False)
        time.sleep(1) # Add a small delay to avoid hitting rate limits

def main():
    """Main function to run the script."""
    try:
        base_df = pd.read_csv(INPUT_FILE)
    except FileNotFoundError:
        print(f"Error: Input file '{INPUT_FILE}' not found.")
        return

    # Check if the output file already exists to resume
    if os.path.exists(OUTPUT_FILE):
        print(f"Found existing output file '{OUTPUT_FILE}'. Resuming...")
        output_df = pd.read_csv(OUTPUT_FILE)
        # Ensure all columns from the base df are present
        for col in base_df.columns:
            if col not in output_df.columns:
                output_df[col] = base_df[col]
    else:
        output_df = base_df.copy()
        # Add columns for the enriched data
        enriched_cols = [
            "description", "ingredient", "dosage", "adverse_effect",
            "preservation", "careful", "short_description", "diseases",
            "cong_dung", "doi_tuong_su_dung", "do_tuoi", "lieu_luong",
            "tan_suat_su_dung", "dang_bao_che", "sources", "enriched"
        ]
        for col in enriched_cols:
             output_df[col] = None
        output_df['enriched'] = output_df['enriched'].astype(bool)


    # Filter for products that have not been enriched yet
    df_to_process = output_df[output_df['enriched'] != True]

    if df_to_process.empty:
        print("All products have already been enriched.")
        return

    enrich_and_save(df_to_process, output_df)

    print(f"\\nEnrichment complete. Data saved to '{OUTPUT_FILE}'.")

if __name__ == "__main__":
    main()
