import pandas as pd
from google import genai
from google.genai import types
import os
import json
from tqdm import tqdm
import time

# --- Configuration ---
API_KEY = os.getenv("GEMINI_API_KEY")
if not API_KEY:
    raise ValueError("GEMINI_API_KEY environment variable not set. Please set it before running.")

MODEL_NAME = 'gemini-2.5-pro'  # It's good practice to use a specific version
INPUT_FILE = 'full_description.csv'
BATCH_INPUT_FILE = 'batch_input.jsonl'
OUTPUT_FILE = 'gemini_enrichment_batch.csv'
BATCH_SIZE = 1000

# --- Prompt Template ---
PROMPT_TEMPLATE = """
tôi đang bán sản phẩm {web_name}, tìm giúp tôi các attributes sau:

description
ingredient
dosage (format đơn giản, chỉ khối lượng của đơn vị nhỏ nhất, chỉ 1 trong 2 đơn vị là g hoặc ml, ví dụ: 500g, 100ml)
adverse_effect
preservation
careful
short_description
diseases (loại bệnh, có thể nhiều, cách nhau bằng dấu phẩy)
cong_dung (công dụng của sản phẩm)
doi_tuong_su_dung (đối tượng sử dụng)
do_tuoi (độ tuổi sử dụng, ví dụ: người lớn/trẻ nhỏ)
lieu_luong (liều lượng):
tan_suat_su_dung (tần suất sử dụng)
dang_bao_che (dạng bào chế, vd Viên nén)

Hiện tại tôi có description không đầy đủ  như sau: {full_description}

Nhiệm vụ của bạn là:

+ kiểm tra xem nội dung và các trường thông tin trên có đủ hoặc thiếu hay không.
+ nếu chưa đầy đủ hãy tìm trên internet và lấy đầy đủ về
+ viết lại description đầy đủ để có thể bán hàng trên mạng.
+ trả lại data cho tôi dưới dạng json chứa tất cả các trường cần thiết và giá trị hợp lí.

{{
    "description" : {{
         "old_value" : "nội dung cũ..." ,
         "new_value" : "str nội dung mới nếu nội dung cũ không phù hợp..."
    }},
   "ingredient": {{ "old_value": "...", "new_value": "..."}},
   "dosage": {{ "old_value": "...", "new_value": "..."}},
   "adverse_effect": {{ "old_value": "...", "new_value": "..."}},
   "preservation": {{ "old_value": "...", "new_value": "..."}},
   "careful": {{ "old_value": "...", "new_value": "..."}},
   "short_description": {{ "old_value": "...", "new_value": "..."}},
   "diseases": {{ "old_value": "...", "new_value": "..."}},
   "cong_dung": {{ "old_value": "...", "new_value": "..."}},
   "doi_tuong_su_dung": {{ "old_value": "...", "new_value": "..."}},
   "do_tuoi": {{ "old_value": "...", "new_value": "..."}},
   "lieu_luong": {{ "old_value": "...", "new_value": "..."}},
   "tan_suat_su_dung": {{ "old_value": "...", "new_value": "..."}},
   "dang_bao_che": {{ "old_value": "...", "new_value": "..."}}
}}
"""

def clean_json_response(text):
    """Extracts the JSON object from the model's response text."""
    try:
        start = text.find('{')
        end = text.rfind('}') + 1
        if start != -1 and end != 0:
            return text[start:end]
    except Exception:
        return None
    return None

def prepare_batch_input(df_to_process, batch_input_file, start_index=0):
    """Prepares the JSONL file for the batch request and uploads it."""
    print(f"Preparing batch input file: {batch_input_file}")
    with open(batch_input_file, 'w') as f:
        for index, row in tqdm(df_to_process.iterrows(), total=df_to_process.shape[0]):
            web_name = row.get('web_name', '')
            full_description = row.get('full_description', '')
            prompt = PROMPT_TEMPLATE.format(web_name=web_name, full_description=full_description)

            # Each line in the JSONL file is a GenerateContentRequest
            request = {
                # The 'key' is a user-defined identifier to match requests with responses
                "key": str(start_index + index),
                "request": {
                    "contents": [{"parts": [{"text": prompt}]}],
                    "tools": [{
                        "googleSearch": {
                            "timeRangeFilter": None
                        }
                    }]
                }
            }
            f.write(json.dumps(request) + '\n')
    print("Batch input file created successfully.")
    
    # Upload the file
    client = genai.Client(api_key=os.environ.get("GEMINI_API_KEY"))
    print(f"Uploading batch input file: {batch_input_file}")
    uploaded_file = client.files.upload(
        file=batch_input_file,
        config=types.UploadFileConfig(display_name='tpcn-enrich-requests', mime_type='jsonl')
    )
    print(f"File uploaded: {uploaded_file.name}")
    return uploaded_file.name

def submit_batch_job(uploaded_file_name):
    """Creates and submits a batch job using an already uploaded file."""
    client = genai.Client(api_key=os.environ.get("GEMINI_API_KEY"))

    print("Creating batch job...")
    job = client.batches.create(
        model=MODEL_NAME,
        src=uploaded_file_name,
        config={
            'display_name': "tpcn-enrich-requests-upload-job",
        },
    )
    job_name = job.name
    print(f"Batch job created: {job_name}")
    print("Waiting for job to complete... (This may take a while)")

    while True:
        batch_job_jsonl = client.batches.get(name=job_name)
        print(f"Job status: {batch_job_jsonl.state.name}")
        if batch_job_jsonl.state.name in ('JOB_STATE_SUCCEEDED', 'JOB_STATE_FAILED', 'JOB_STATE_CANCELLED', 'JOB_STATE_EXPIRED'):
            break
        time.sleep(60)  # Poll every minute

    if batch_job_jsonl.state.name != 'JOB_STATE_SUCCEEDED':
        raise Exception(f"Batch job failed: {job.error}")

    print("Batch job completed successfully!")
    return batch_job_jsonl

def process_and_save_results(job, output_df):
    """Retrieves results from the completed job and saves them."""
    client = genai.Client(api_key=os.environ.get("GEMINI_API_KEY"))
    print("Processing batch results...")
    result_file_name = job.dest.file_name
    result_file = client.files.download(file=result_file_name)

    # The result is a JSONL file
    result_content = result_file.decode('utf-8')
    result_lines = result_content.strip().split('\n')

    for line in tqdm(result_lines, desc="Processing responses"):
        response_data = json.loads(line)
        index = int(response_data['key'])

        try:
            # Extract the generated text from the response
            response_text = response_data['response']['candidates'][0]['content']['parts'][0]['text']
            json_str = clean_json_response(response_text)

            if json_str:
                data = json.loads(json_str)
                for key, value in data.items():
                    if key in output_df.columns:
                        output_df.loc[index, key] = value.get('new_value')
                output_df.loc[index, 'enriched'] = True
            else:
                output_df.loc[index, 'enriched'] = False

        except (KeyError, IndexError, json.JSONDecodeError) as e:
            print(f"Error processing response for key {index}: {e}")
            output_df.loc[index, 'enriched'] = False

    print(f"Batch results processed.")
    return output_df


def main():
    """Main function to run the batch processing script."""
    try:
        base_df = pd.read_csv(INPUT_FILE)
    except FileNotFoundError:
        print(f"Error: Input file '{INPUT_FILE}' not found.")
        return

    # For batch processing, we'll create a fresh output file
    # and process all data in batches.
    output_df = base_df.copy()
    enriched_cols = [
        "description", "ingredient", "dosage", "adverse_effect",
        "preservation", "careful", "short_description", "diseases",
        "cong_dung", "doi_tuong_su_dung", "do_tuoi", "lieu_luong",
        "tan_suat_su_dung", "dang_bao_che", "enriched"
    ]
    for col in enriched_cols:
        if col not in output_df.columns:
            output_df[col] = None
    output_df['enriched'] = output_df['enriched'].astype(bool)
    
    # Process data in batches
    total_rows = len(output_df)
    num_batches = (total_rows + BATCH_SIZE - 1) // BATCH_SIZE
    
    print(f"Processing {total_rows} rows in {num_batches} batches of size {BATCH_SIZE}")
    
    # Upload all batch files first
    uploaded_files = []
    for i in range(num_batches):
        start_idx = i * BATCH_SIZE
        end_idx = min((i + 1) * BATCH_SIZE, total_rows)
        batch_df = output_df.iloc[start_idx:end_idx]
        
        batch_file = f"batch_input_{i}.jsonl"
        uploaded_file_name = prepare_batch_input(batch_df, batch_file, start_idx)
        uploaded_files.append((uploaded_file_name, start_idx, end_idx))
    
    # Submit jobs one by one and wait for completion
    for i, (uploaded_file_name, start_idx, end_idx) in enumerate(uploaded_files):
        print(f"Processing batch {i+1}/{num_batches} (rows {start_idx} to {end_idx-1})")
        completed_job = submit_batch_job(uploaded_file_name)
        output_df = process_and_save_results(completed_job, output_df)
        # Save intermediate results
        output_df.to_csv(OUTPUT_FILE, index=False)
        print(f"Results saved to '{OUTPUT_FILE}' after batch {i+1}")
    
    print(f"Enrichment complete. Data saved to '{OUTPUT_FILE}'.")

if __name__ == "__main__":
    main()
