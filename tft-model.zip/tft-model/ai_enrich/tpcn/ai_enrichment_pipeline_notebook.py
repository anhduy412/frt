# Databricks notebook source
# DBTITLE 1, Widget and Parameter Setup
dbutils.widgets.text("group_id", "than_kinh_nao", "Group ID to process")
GROUP_ID = dbutils.widgets.get("group_id")

# COMMAND ----------

# DBTITLE 1, Imports and Header
import pyspark.sql.functions as F
from pyspark.sql.types import StringType, StructType, StructField, MapType, Iterator
from pyspark.sql import SparkSession
import pandas as pd
from google import genai
from google.genai import types
import os
import json
import time
import concurrent.futures
from shared_udf import setup_catalog

# COMMAND ----------

# DBTITLE 1, Spark, Catalog, and API Key Configuration
spark = SparkSession.builder.getOrCreate()

# Initialize Catalog
CATALOG_NAME = setup_catalog()
DATABASE = 'tft_serving'

# Securely retrieve the Gemini API Key from Databricks Secrets
env = os.getenv('MY_ENV', '').lower()
env_kv = '' if env == '' else env + '-'

SCOPE = f'{env_kv}dataplatform-vault-scope'

GEMINI_API_KEY = dbutils.secrets.get(scope=SCOPE, key="frt-gemini-api-key")
os.environ["GEMINI_API_KEY"] = GEMINI_API_KEY

print(f"Successfully configured for Catalog: '{CATALOG_NAME}' and Group ID: {GROUP_ID}")

# COMMAND ----------

# DBTITLE 1, Data Ingestion - Fetching target attributes
print("Fetching target attributes and applying exclusions...")
# Read the list of attributes to exclude from AI enrichment
try:
    exclude_df = spark.table(f"{CATALOG_NAME}.{DATABASE}.config_ai_exclude_features").select("attribute_id")
    print(f"Found {exclude_df.count()} attributes to exclude.")
except Exception as e:
    print("Could not find or read the exclusion table `config_ai_exclude_features`. Proceeding without exclusions.")
    exclude_df = spark.createDataFrame([], StructType([StructField("attribute_id", StringType(), False)]))


# Fetch all active attributes from the master table (no group_id)
master_attributes_df = spark.table(f"{CATALOG_NAME}.{DATABASE}.standard_sku_features") \
    .drop("group_id") \
    .filter(F.col("active") == True)

# Determine relevant attributes by checking the values table for the selected group(s)
values_for_group_df = spark.table(f"{CATALOG_NAME}.{DATABASE}.standard_sku_features_value")
if GROUP_ID.lower() != 'all':
    values_for_group_df = values_for_group_df.filter(F.col("group_id") == GROUP_ID)

# Get the list of attributes that are actually used for the selected group(s)
relevant_attributes_df = values_for_group_df.select("attribute_id", "group_id").distinct() \
    .join(master_attributes_df, "attribute_id")

# Filter out the excluded attributes and create a lookup dictionary
# Add an 'is_excluded' flag to each attribute. Excluded attributes are kept for context but not for enrichment.
attributes_with_exclude_flag_df = relevant_attributes_df.join(
    exclude_df.withColumn("is_excluded", F.lit(True)),
    "attribute_id",
    "left"
).na.fill(False, ["is_excluded"])

# Create a lookup dictionary that includes the exclusion flag
attributes_by_group_rows = attributes_with_exclude_flag_df.groupBy("group_id") \
    .agg(F.collect_list(F.struct("attribute_name", "description", "is_excluded")).alias("attributes")) \
    .collect()

attributes_by_group = {
    row['group_id']: [
        {'name': r['attribute_name'], 'desc': r['description'], 'is_excluded': r['is_excluded']} for r in row['attributes']
    ] for row in attributes_by_group_rows
}
print(f"Prepared attributes for {len(attributes_by_group)} group(s), flagging excluded ones.")

# COMMAND ----------

# DBTITLE 1, Data Preparation - Pivoting the source data
print("Fetching and preparing source data...")
# First, get attribute names for values
values_df = spark.table(f"{CATALOG_NAME}.{DATABASE}.standard_sku_features_value")
attributes_info_df = spark.table(f"{CATALOG_NAME}.{DATABASE}.standard_sku_features").select("attribute_id", "attribute_name")

# Apply group_id filter upfront if not "all"
if GROUP_ID.lower() != 'all':
    values_df = values_df.filter(F.col("group_id") == GROUP_ID)

# Identify SKUs that have at least one attribute needing enrichment from the filtered data
# A SKU needs to be processed if it has at least one NULL `value_ai` for a non-excluded attribute.
values_to_check_df = values_df.join(exclude_df, "attribute_id", "left_anti")
skus_to_process_df = values_to_check_df.filter(F.col("value_ai").isNull()).select("sku").distinct()

# Join back to the main dataframe to get all attributes for the SKUs that need processing.
# This ensures that we have the full context for the pivot operation.
values_to_process_df = values_df.join(skus_to_process_df, "sku", "inner")

sku_values_to_process_df = values_to_process_df.join(attributes_info_df, "attribute_id")

# Pivot to get one row per SKU and group, collecting both original and existing AI values
pivoted_sku_df = sku_values_to_process_df.groupBy("sku", "group_id").pivot("attribute_name") \
    .agg(F.first("value_original").alias("original"), F.first("value_ai").alias("ai"))

print("Data preparation complete. Collecting SKUs to process on the driver.")
pivoted_rows = pivoted_sku_df.collect()
total_skus_to_process = len(pivoted_rows)
print(f"Found {total_skus_to_process} SKUs to process.")

# COMMAND ----------

# DBTITLE 1,Iterative Enrichment and Merging
PROMPT_TEMPLATE = """
Nhiệm vụ của bạn là làm giàu thông tin sản phẩm. Dựa trên dữ liệu sản phẩm được cung cấp, vui lòng xem xét và cải thiện các thuộc tính sau.
Nếu thông tin hiện có cho một thuộc tính không đầy đủ hoặc không chính xác, hãy tìm thông tin đúng và cung cấp dưới dạng 'new_value'.
Nếu thông tin hiện có đã tốt, bạn có thể trả lại nó trong 'new_value'.
Nếu bạn không thể tìm thấy thông tin cho một thuộc tính, hãy điền "not_available" vào 'new_value'.

Trả lại kết quả dưới dạng một đối tượng JSON duy nhất. Mỗi khóa trong đối tượng phải là tên thuộc tính,
và giá trị của nó phải là một đối tượng JSON khác chứa "old_value" và "new_value".

**Các thuộc tính cần làm giàu và mô tả của chúng:**
{attributes_description}

**Thông tin sản phẩm (với các giá trị hiện tại):**
{context_json}

**Định dạng đầu ra ví dụ:**
{{
    "ten_thuoc_tinh_1": {{ "old_value": "...", "new_value": "..." }},
    "ten_thuoc_tinh_2": {{ "old_value": "...", "new_value": "..." }}
}}
"""

def clean_json_response(text):
    """Extracts the JSON object from the model's response text."""
    try:
        start = text.find('{')
        end = text.rfind('}') + 1
        if start != -1 and end != 0:
            return text[start:end]
    except Exception:
        return None
    return None

# Configure Gemini client on the driver
client = genai.Client(api_key=os.environ.get("GEMINI_API_KEY"))
grounding_tool = types.Tool(google_search=types.GoogleSearch())
client_config = types.GenerateContentConfig(tools=[grounding_tool])

def call_gemini_api(prompt, sku):
    """Calls the Gemini API with retry logic and validates all new_value fields are strings."""
    max_retries = 10
    for attempt in range(max_retries):
        try:
            response = client.models.generate_content(
                model="gemini-2.5-pro",
                contents=prompt,
                config=client_config
            )
            json_response = clean_json_response(response.text)
            if json_response:
                parsed = json.loads(json_response)
                # Validate all new_value fields are strings
                for attr, values in parsed.items():
                    if (
                        'new_value' not in values or
                        not isinstance(values['new_value'], str)
                    ):
                        raise ValueError(f"new_value for attribute '{attr}' is not a string or missing")
                return json_response
            else:
                raise ValueError("Malformed JSON response")
        except Exception as e:
            print(f"  > Attempt {attempt + 1} failed for SKU {sku}: {e}")
            if attempt < max_retries - 1:
                time.sleep(5)
    return None

def process_sku_for_enrichment(row):
    """Prepares prompt, calls API, and processes result for a single SKU."""
    current_sku = row['sku']
    current_group_id = row['group_id']
    
    context_dict = {}
    row_dict = row.asDict()

    all_attributes_for_group = attributes_by_group.get(current_group_id, [])
    if not all_attributes_for_group:
        return {'sku': current_sku, 'status': 'skipped', 'reason': f"No attributes found for group {current_group_id}"}

    attributes_description_str = ""
    needs_enrichment = False
    
    for attr_info in all_attributes_for_group:
        attr_name = attr_info['name']
        original_col = f"{attr_name}_original"
        ai_col = f"{attr_name}_ai"

        if original_col in row_dict:
            context_dict[attr_name] = {"old_value": row_dict.get(original_col)}

        if not attr_info['is_excluded']:
            attr_desc = attr_info['desc']
            attributes_description_str += f"- {attr_name}: {attr_desc}\n"
            
            if original_col in row_dict and row_dict.get(ai_col) is None:
                needs_enrichment = True

    if not needs_enrichment:
        return {'sku': current_sku, 'status': 'skipped', 'reason': "No non-excluded attributes needing enrichment"}

    context_json = json.dumps(context_dict, ensure_ascii=False, indent=4)
    prompt = PROMPT_TEMPLATE.format(
        attributes_description=attributes_description_str,
        context_json=context_json
    )

    json_str = call_gemini_api(prompt, current_sku)

    if not json_str:
        raise Exception("API call failed after all retries.")

    try:
        enriched_data = json.loads(json_str)
        update_rows = []
        for attr_name, values in enriched_data.items():
            if 'new_value' in values:
                new_value = values['new_value']
                if new_value is None or str(new_value).strip() == '':
                    new_value = "not_available"
                update_rows.append((current_sku, attr_name, new_value))
        
        return {"sku": current_sku, "status": "success", "update_rows": update_rows}

    except Exception as e:
        raise Exception(f"Failed to process JSON response for SKU {current_sku}: {e}")


total_attributes_updated = 0
skus_processed = 0
BATCH_SIZE = 50

print(f"Starting batched enrichment for {total_skus_to_process} SKUs with batch size {BATCH_SIZE}...")

for i in range(0, total_skus_to_process, BATCH_SIZE):
    batch_rows = pivoted_rows[i:i + BATCH_SIZE]
    batch_number = (i // BATCH_SIZE) + 1
    total_batches = (total_skus_to_process + BATCH_SIZE - 1) // BATCH_SIZE
    print(f"\n--- Processing Batch {batch_number}/{total_batches} ({len(batch_rows)} SKUs) ---")

    successful_results = []
    failed_rows_for_retry = []

    with concurrent.futures.ThreadPoolExecutor(max_workers=BATCH_SIZE) as executor:
        future_to_row = {executor.submit(process_sku_for_enrichment, row): row for row in batch_rows}

        for future in concurrent.futures.as_completed(future_to_row):
            row = future_to_row[future]
            try:
                result = future.result()
                if result and result.get('status') == 'success':
                    successful_results.append(result)
                elif result and result.get('status') == 'skipped':
                     print(f"  > SKU {result['sku']} skipped: {result['reason']}")
            except Exception as exc:
                print(f"  > Initial processing failed for SKU {row['sku']}: {exc}")
                failed_rows_for_retry.append(row)
    
    if failed_rows_for_retry:
        print(f"\n--- Retrying {len(failed_rows_for_retry)} failed SKUs for Batch {batch_number} ---")
        for row in failed_rows_for_retry:
            current_sku = row['sku']
            print(f"  > Retrying SKU: {current_sku}")
            try:
                result = process_sku_for_enrichment(row)
                if result and result.get('status') == 'success':
                    successful_results.append(result)
                    print(f"  > Retry successful for SKU: {current_sku}")
                elif result and result.get('status') == 'skipped':
                    print(f"  > SKU {current_sku} skipped on retry: {result['reason']}")
                else:
                    print(f"  > Retry for SKU {current_sku} did not succeed or was skipped.")
            except Exception as e:
                print(f"  > Retry failed for SKU {current_sku}: {e}")
            
            time.sleep(1)

    if not successful_results:
        print(f"--- No SKUs successfully processed in Batch {batch_number}. Skipping merge. ---")
        skus_processed += len(batch_rows)
        continue

    all_update_rows = []
    print(f"\n--- Preparing to merge results for Batch {batch_number} ---")
    for res in successful_results:
        all_update_rows.extend(res['update_rows'])
        print(f"  > SKU {res['sku']} processed with {len(res['update_rows'])} updates.")

    if not all_update_rows:
        print(f"--- No attributes to update in Batch {batch_number}. Skipping merge. ---")
        skus_processed += len(batch_rows)
        continue

    try:
        updates_df = spark.createDataFrame(all_update_rows, ["sku", "attribute_name", "value_ai"]) \
            .join(attributes_info_df, "attribute_name") \
            .select("sku", "attribute_id", "value_ai")

        updates_df.createOrReplaceTempView("enriched_updates_temp_batch")

        merge_sql = f"""
            MERGE INTO {CATALOG_NAME}.{DATABASE}.standard_sku_features_value AS target
            USING enriched_updates_temp_batch AS source
            ON target.sku = source.sku
               AND target.attribute_id = source.attribute_id
            WHEN MATCHED AND target.value_ai IS NULL THEN
              UPDATE SET target.value_ai = source.value_ai
        """

        spark.sql(merge_sql)
        num_updated = updates_df.count()
        total_attributes_updated += num_updated
        print(f"  > Successfully merged {num_updated} attributes for Batch {batch_number}.")

        if num_updated > 0:
            print(f"\n--- Optimizing table after Batch {batch_number} ---")
            spark.sql(f"OPTIMIZE {CATALOG_NAME}.{DATABASE}.standard_sku_features_value")

    except Exception as e:
        print(f"  > Failed to merge results for Batch {batch_number}: {e}")

    skus_processed += len(batch_rows)


# COMMAND ----------

# DBTITLE 1, Final Summary
print("\n------------------------------------")
print("Enrichment process complete.")
print(f"Total SKUs processed: {skus_processed}/{total_skus_to_process}")
print(f"Total attribute values updated: {total_attributes_updated}")


# COMMAND ----------

# DBTITLE 1, Optimize Table
if total_attributes_updated > 0:
    print("\n------------------------------------")
    print(f"Optimizing the target table: {CATALOG_NAME}.{DATABASE}.standard_sku_features_value")
    spark.sql(f"OPTIMIZE {CATALOG_NAME}.{DATABASE}.standard_sku_features_value")
    print("Optimization complete.")
