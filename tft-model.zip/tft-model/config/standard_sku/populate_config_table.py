# This script reads CSV files from a Unity Catalog Volume and creates Delta tables.
# It is designed to be run as a standard Python script within a Databricks environment
# (e.g., as a job or executed from a notebook).

import json
import sys
from pyspark.sql import SparkSession
from pyspark.sql.functions import lit, current_timestamp
from delta.tables import DeltaTable
from shared_udf import setup_catalog

# --- Base Configuration ---
CATALOG_NAME = setup_catalog()
DATABASE_NAME = "mrp_dw"
CONFIG_TABLE_NAME = f"{CATALOG_NAME}.{DATABASE_NAME}.standard_sku_clustering_configs"

# --- Configuration for 'chong_nang' ---
chong_nang_config = {
    'INPUT_TABLE': (f'{CATALOG_NAME}.{DATABASE_NAME}.standard_sku_dmp_chong_nang_features', 'string'),
    'SALES_HISTORY_TABLE': ('', 'string'), # No sales history for this one
    'DESCRIPTION_EMBEDDING_TABLE': (f'{CATALOG_NAME}.{DATABASE_NAME}.standard_sku_dmp_chong_nang_embeddings', 'string'),
    'PCA_EXPLAINED_VARIANCE': (0.99, 'float'),
    'HDBSCAN_PARAMS': ({
        'min_cluster_size': 2, 'min_samples': 1, 'metric': 'euclidean',
        'cluster_selection_method': 'eom', 'algorithm': 'generic'
    }, 'json'),
    'GROUPING_FEATURES': (['dosageforms'], 'json'),
    'NUMERICAL_FEATURES': (['pricelv1-norm', 'spf', 'weightvolume-no'], 'json'),
    'CATEGORICAL_FEATURES': (['skin', 'brand', 'brandorigin', 'usageroutelc', 'salechannel'], 'json'),
    'MULTI_LABEL_FEATURES': (['skin'], 'json'),
    'MULTI_LABEL_ALL_SELECTOR': ({'skin': 'moi-loai-da'}, 'json'),
    'FEATURE_WEIGHTS': ({'weightvolume-no': 2.0, 'pricelv1-norm': 6.0, 'skin': 2.0, 'spf': 2.0}, 'json'),
    'NUM_TO_CAT_CONFIG': ({'enabled': False}, 'json'),
    'CAT_MERGE_CONFIG': ({'enabled': False}, 'json'),
    'BEHAVIORAL_DISTANCE_WEIGHT': (0.25, 'float'),
    'MIN_COMMON_DAYS_FOR_CORRELATION': (10, 'int'),
    'PRICE_COLUMN': ('pricelv1-norm', 'string'),
    'DESCRIPTION_EMBEDDING_DISTANCE_WEIGHT': (1.5, 'float'),
    'PLOTTING_CONFIG': ({'enabled': False, 'tsne_plots': True, 'dendrogram_plots': True}, 'json'),
    'USE_BEHAVIORAL_DATA': (False, 'boolean'),
    'USE_EMBEDDING_DATA': (False, 'boolean')
}

# --- Configuration for 'khang_sinh' ---
khang_sinh_config = {
    'INPUT_TABLE': (f'{CATALOG_NAME}.{DATABASE_NAME}.standard_sku_khang_sinh_features', 'string'),
    'SALES_HISTORY_TABLE': (f'{CATALOG_NAME}.{DATABASE_NAME}.standard_sku_khang_sinh_sales_stock_90_days', 'string'),
    'DESCRIPTION_EMBEDDING_TABLE': ('', 'string'), # No embeddings for this one
    'PCA_EXPLAINED_VARIANCE': (0.95, 'float'),
    'HDBSCAN_PARAMS': ({
        'min_cluster_size': 2, 'min_samples': 1, 'metric': 'euclidean',
        'cluster_selection_method': 'eom', 'algorithm': 'generic'
    }, 'json'),
    'GROUPING_FEATURES': (['compositiongroupname', 'ingredientunitname', 'groupdosageformname', 'ingredientamount'], 'json'),
    'NUMERICAL_FEATURES': (['sellingpriceperingredientunit'], 'json'),
    'CATEGORICAL_FEATURES': (['nha-san-xuat', 'bao-quan'], 'json'),
    'MULTI_LABEL_FEATURES': ([], 'json'),
    'FEATURE_WEIGHTS': ({
        'nha-san-xuat': 1.0, 'sellingpriceperingredientunit': 1.0, 'duong-dung': 0.0,
        'bao-quan': 0.0, 'thuong-hieu': 0.0, 'unitcombine': 0.0
    }, 'json'),
    'NUM_TO_CAT_CONFIG': ({
        'enabled': False, 'features': {
            'sellingpriceperingredientunit': {
                'variation_threshold': 0.25, 'high_variation_bins': 3,
                'high_variation_labels': ['low_price', 'mid_price', 'high_price']
            }
        }
    }, 'json'),
    'CAT_MERGE_CONFIG': ({
        'enabled': False, 'merges': [{
            'name': 'price_mfr_combo', 'features': ['sellingpriceperingredientunit_cat', 'nha-san-xuat'], 'weight': 4.0
        }]
    }, 'json'),
    'BEHAVIORAL_DISTANCE_WEIGHT': (0.25, 'float'),
    'MIN_COMMON_DAYS_FOR_CORRELATION': (10, 'int'),
    'PRICE_COLUMN': ('sellingpriceperingredientunit', 'string'),
    'DESCRIPTION_EMBEDDING_DISTANCE_WEIGHT': (1.5, 'float'), # Default, but not used
    'PLOTTING_CONFIG': ({'enabled': False, 'tsne_plots': True, 'dendrogram_plots': True}, 'json'),
    'USE_BEHAVIORAL_DATA': (False, 'boolean'),
    'USE_EMBEDDING_DATA': (False, 'boolean')
}

# Dictionary to hold all configurations
ALL_CONFIGS = {
    "chong_nang": chong_nang_config,
    "khang_sinh": khang_sinh_config
}

def create_and_merge_config(spark: SparkSession, config_dict: dict, config_set_name: str, table_name: str):
    """Converts a config dictionary to a Spark DataFrame and merges it into the target Delta table."""
    print(f"--- Processing configuration for '{config_set_name}' ---")

    records = []
    for key, (value, value_type) in config_dict.items():
        param_value = json.dumps(value) if value_type == 'json' else str(value)
        records.append({
            'config_set': config_set_name, 'param_key': key,
            'param_value': param_value, 'param_type': value_type
        })

    config_df = spark.createDataFrame(records)
    final_df = config_df.withColumn("last_updated_at", current_timestamp())

    print(f"Writing configuration to {table_name}...")

    delta_table = DeltaTable.forName(spark, table_name)
    (
        delta_table.alias("target")
        .merge(
            final_df.alias("source"),
            "target.config_set = source.config_set AND target.param_key = source.param_key"
        )
        .whenMatchedUpdate(set={
            "param_value": "source.param_value", "param_type": "source.param_type",
            "last_updated_at": "source.last_updated_at"
        })
        .whenNotMatchedInsertAll()
        .execute()
    )
    print(f"Successfully merged configuration for '{config_set_name}'.\n")

def main(spark: SparkSession):
    """Main execution logic."""
    print("Starting script to populate clustering configurations...")

    for name, config_data in ALL_CONFIGS.items():
        create_and_merge_config(spark, config_data, name, CONFIG_TABLE_NAME)

    print("--- All configurations processed successfully. ---")

if __name__ == "__main__":
    spark_session = SparkSession.builder.appName("PopulateAllConfigs").getOrCreate()
    main(spark_session)
