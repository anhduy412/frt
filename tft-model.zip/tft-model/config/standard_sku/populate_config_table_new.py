# This script populates the new configuration table for the hybrid clustering model.
# It is designed to be run as a standard Python script within a Databricks environment.

import json
from pyspark.sql import SparkSession
from pyspark.sql.functions import current_timestamp
from delta.tables import DeltaTable
from shared_udf import setup_catalog

# --- Base Configuration ---
CATALOG_NAME = setup_catalog()
DATABASE_NAME = "tft_serving"
CONFIG_TABLE_NAME = f"{CATALOG_NAME}.{DATABASE_NAME}.config_kmean"

# # --- Configuration for 'chong_nang' group ---
# chong_nang_config = {
#     'GROUPING_FEATURES': (['dosageforms'], 'json'),
#     'NUMERICAL_FEATURES': (['sellingpriceperingredientunit', 'spf', 'weightvolume-no'], 'json'),
#     'CATEGORICAL_FEATURES': (['skin', 'brand', 'brandorigin', 'usageroutelc', 'salechannel'], 'json'),
#     'EMBEDDING_FEATURES': (['description'], 'json'), # Example: Using 'description' as an embedding feature
#     'MULTI_LABEL_FEATURES': (['skin'], 'json'),
#     'MULTI_LABEL_ALL_SELECTOR': ({'skin': 'moi-loai-da'}, 'json'),
#     'FEATURE_WEIGHTS': ({
#         'static_features': 1.0,
#         'behavioral_features': 1.0,
#         'embedding_description': 1.5, # Weight for the 'description' embedding feature
#         'weightvolume-no': 2.0,
#         'sellingpriceperingredientunit': 6.0,
#         'skin': 2.0,
#         'spf': 2.0
#     }, 'json'),
#     'HDBSCAN_PARAMS': ({
#         'min_cluster_size': 2, 'min_samples': 1,
#         'cluster_selection_method': 'eom', 'algorithm': 'generic'
#     }, 'json'),
#     'PCA_EXPLAINED_VARIANCE': (0.99, 'float'),
#     'USE_BEHAVIORAL_DATA': (False, 'boolean'),
#     'SALES_HISTORY_TABLE': ('', 'string'),
#     'MIN_COMMON_DAYS_FOR_CORRELATION': (10, 'int'),
#     'PRICE_COLUMN': ('sellingpriceperingredientunit', 'string'),
#     'MIN_GROUP_SIZE_FOR_CLUSTERING': (3, 'int'),
#     'MAX_K_FOR_OUTLIERS': (10, 'int')
# }

# # --- Configuration for 'khang_sinh' group ---
# khang_sinh_config = {
#     'GROUPING_FEATURES': (['compositiongroupname', 'ingredientunitname', 'groupdosageformname', 'ingredientamount'], 'json'),
#     'NUMERICAL_FEATURES': (['sellingpriceperingredientunit'], 'json'),
#     'CATEGORICAL_FEATURES': (['nha-san-xuat', 'bao-quan'], 'json'),
#     'EMBEDDING_FEATURES': ([], 'json'), # No embeddings for this group
#     'MULTI_LABEL_FEATURES': ([], 'json'),
#     'FEATURE_WEIGHTS': ({
#         'static_features': 1.0,
#         'behavioral_features': 1.5, # Higher weight for sales data
#         'nha-san-xuat': 1.0,
#         'sellingpriceperingredientunit': 1.0,
#         'bao-quan': 0.5
#     }, 'json'),
#     'HDBSCAN_PARAMS': ({
#         'min_cluster_size': 2, 'min_samples': 1,
#         'cluster_selection_method': 'eom', 'algorithm': 'generic'
#     }, 'json'),
#     'PCA_EXPLAINED_VARIANCE': (0.95, 'float'),
#     'USE_BEHAVIORAL_DATA': (True, 'boolean'),
#     'SALES_HISTORY_TABLE': (f'{CATALOG_NAME}.mrp_dw.standard_sku_khang_sinh_sales_stock_90_days', 'string'),
#     'MIN_COMMON_DAYS_FOR_CORRELATION': (10, 'int'),
#     'PRICE_COLUMN': ('sellingpriceperingredientunit', 'string'),
#     'MIN_GROUP_SIZE_FOR_CLUSTERING': (3, 'int'),
#     'MAX_K_FOR_OUTLIERS': (10, 'int')
# }

than_kinh_nao_config = {
    'GROUPING_FEATURES': ([], 'json'),
    'NUMERICAL_FEATURES': (['sellingPrice'], 'json'),
    'CATEGORICAL_FEATURES': (['BrandOrigin', 'ProductSpecs', 'Manufactor', 'Brand'], 'json'),
    'EMBEDDING_FEATURES': (['ingredient', 'short_description', 'dosage', 'usage', 'description', 'DosageForms', 'ObjectUse', 'AgeUse', 'Warning'], 'json'), # No embeddings for this group
    'MULTI_LABEL_FEATURES': ([], 'json'),
    'FEATURE_WEIGHTS': ({
        'behavioral_features': 1.0,
        'sellingPrice': 2.5,
        'usage': 2.0,
        'ObjectUse': 2.0,
        'Warning': 1.5,
    }, 'json'),
    'HDBSCAN_PARAMS': ({
        'min_cluster_size': 2, 'min_samples': 1,
        'cluster_selection_method': 'eom', 'algorithm': 'generic'
    }, 'json'),
    'PCA_EXPLAINED_VARIANCE': (0.95, 'float'),
    'USE_BEHAVIORAL_DATA': (False, 'boolean'),
    'PRICE_COLUMN': ('sellingPrice', 'string'),
    'MIN_GROUP_SIZE_FOR_CLUSTERING': (3, 'int'),
    'MAX_K_FOR_OUTLIERS': (1000, 'int')
}

# Dictionary to hold all configurations by group_id
ALL_CONFIGS = {
    # "khang_sinh": khang_sinh_config,
    # "chong_nang": chong_nang_config,
    "than_kinh_nao": than_kinh_nao_config,
}

def create_and_merge_config(spark: SparkSession, config_dict: dict, group_id: str, table_name: str):
    """Converts a config dictionary to a Spark DataFrame and merges it into the target Delta table."""
    print(f"--- Processing configuration for group_id '{group_id}' ---")

    records = []
    for key, (value, value_type) in config_dict.items():
        param_value = json.dumps(value) if value_type == 'json' else str(value)
        records.append({
            'group_id': group_id, 'param_key': key,
            'param_value': param_value, 'param_type': value_type
        })

    config_df = spark.createDataFrame(records)
    final_df = config_df.withColumn("last_updated_at", current_timestamp())

    print(f"Writing configuration to {table_name}...")

    # Ensure the target table exists, creating it if necessary
    # Note: For production, a more robust schema definition is recommended.
    spark.sql(f"CREATE TABLE IF NOT EXISTS {table_name} (group_id STRING, param_key STRING, param_value STRING, param_type STRING, last_updated_at TIMESTAMP) USING DELTA")

    delta_table = DeltaTable.forName(spark, table_name)
    (
        delta_table.alias("target")
        .merge(
            final_df.alias("source"),
            "target.group_id = source.group_id AND target.param_key = source.param_key"
        )
        .whenMatchedUpdate(set={
            "param_value": "source.param_value", "param_type": "source.param_type",
            "last_updated_at": "source.last_updated_at"
        })
        .whenNotMatchedInsertAll()
        .execute()
    )
    print(f"Successfully merged configuration for group_id '{group_id}'.\n")

def main(spark: SparkSession):
    """Main execution logic."""
    print("Starting script to populate new clustering configurations...")

    for group_id, config_data in ALL_CONFIGS.items():
        create_and_merge_config(spark, config_data, group_id, CONFIG_TABLE_NAME)

    print("--- All configurations processed successfully. ---")

if __name__ == "__main__":
    spark_session = SparkSession.builder.appName("PopulateNewClusteringConfigs").getOrCreate()
    main(spark_session)
