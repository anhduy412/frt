# Managing Clustering Configurations in Databricks

This document provides examples of how to create, update, and manage entries in the `clustering_configs` table using both Spark SQL and PySpark.

**Prerequisites:**
- The `clustering_configs` table has been created.
- You have a catalog and database (schema) to work in.

Let's assume your table is located at `your_catalog.your_database.clustering_configs`.

---

## 1. Inserting a New Configuration Parameter

### Example: Adding `PCA_EXPLAINED_VARIANCE`

#### Using Spark SQL

```sql
INSERT INTO your_catalog.your_database.clustering_configs
(config_set, param_key, param_value, param_type, last_updated_at)
VALUES
('chong_nang', 'PCA_EXPLAINED_VARIANCE', '0.99', 'float', current_timestamp());
```

#### Using PySpark

```python
from pyspark.sql.functions import lit, current_timestamp

# Create a DataFrame for the new parameter
new_param_df = spark.createDataFrame([
    ('chong_nang', 'PCA_EXPLAINED_VARIANCE', '0.99', 'float')
], ["config_set", "param_key", "param_value", "param_type"])

# Add the timestamp and write to the table
new_param_df.withColumn("last_updated_at", current_timestamp()) \
    .write \
    .format("delta") \
    .mode("append") \
    .saveAsTable("your_catalog.your_database.clustering_configs")
```

---

## 2. Inserting a JSON Configuration Parameter

### Example: Adding `HDBSCAN_PARAMS`

#### Using Spark SQL

Note: The JSON string must be properly escaped.

```sql
INSERT INTO your_catalog.your_database.clustering_configs
(config_set, param_key, param_value, param_type, last_updated_at)
VALUES
('chong_nang', 'HDBSCAN_PARAMS', '{"min_cluster_size": 2, "min_samples": 1, "metric": "euclidean"}', 'json', current_timestamp());
```

#### Using PySpark

Using Python's `json` library makes this cleaner.

```python
import json
from pyspark.sql.functions import lit, current_timestamp

hdbscan_params = {
    'min_cluster_size': 2,
    'min_samples': 1,
    'metric': 'euclidean'
}

# Create a DataFrame
new_param_df = spark.createDataFrame([
    ('chong_nang', 'HDBSCAN_PARAMS', json.dumps(hdbscan_params), 'json')
], ["config_set", "param_key", "param_value", "param_type"])

# Write to the table
new_param_df.withColumn("last_updated_at", current_timestamp()) \
    .write \
    .format("delta") \
    .mode("append") \
    .saveAsTable("your_catalog.your_database.clustering_configs")
```

---

## 3. Updating an Existing Configuration Parameter

The best way to handle updates is with a `MERGE` statement, which will update a record if it exists or insert it if it doesn't.

### Example: Changing `BEHAVIORAL_DISTANCE_WEIGHT`

#### Using Spark SQL

```sql
MERGE INTO your_catalog.your_database.clustering_configs AS target
USING (SELECT 'chong_nang' as config_set, 'BEHAVIORAL_DISTANCE_WEIGHT' as param_key, '0.30' as param_value, 'float' as param_type) AS source
ON target.config_set = source.config_set AND target.param_key = source.param_key
WHEN MATCHED THEN
  UPDATE SET
    target.param_value = source.param_value,
    target.last_updated_at = current_timestamp()
WHEN NOT MATCHED THEN
  INSERT (config_set, param_key, param_value, param_type, last_updated_at)
  VALUES (source.config_set, source.param_key, source.param_value, source.param_type, current_timestamp());
```

#### Using PySpark (Corrected)

```python
from pyspark.sql.functions import lit, current_timestamp
from delta.tables import DeltaTable

# DataFrame with the new/updated value
update_df = spark.createDataFrame([
    ('chong_nang', 'BEHAVIORAL_DISTANCE_WEIGHT', '0.30', 'float')
], ["config_set", "param_key", "param_value", "param_type"]) \
.withColumn("last_updated_at", current_timestamp())

# Get the DeltaTable object for the target table
delta_table = DeltaTable.forName(spark, "your_catalog.your_database.clustering_configs")

# Perform the merge operation
delta_table.alias("target") \
    .merge(
        update_df.alias("source"),
        "target.config_set = source.config_set AND target.param_key = source.param_key"
    ) \
    .whenMatchedUpdate(set={
        "param_value": "source.param_value",
        "last_updated_at": "source.last_updated_at"
    }) \
    .whenNotMatchedInsertAll() \
    .execute()
```

---

## 4. Deleting a Configuration Parameter

### Example: Removing `PLOTTING_CONFIG`

#### Using Spark SQL

```sql
DELETE FROM your_catalog.your_database.clustering_configs
WHERE config_set = 'chong_nang' AND param_key = 'PLOTTING_CONFIG';
```

#### Using PySpark

```python
from delta.tables import DeltaTable

delta_table = DeltaTable.forName(spark, "your_catalog.your_database.clustering_configs")

delta_table.delete("config_set = 'chong_nang' AND param_key = 'PLOTTING_CONFIG'")
```